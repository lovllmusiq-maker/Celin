# 🚀 CodeQuest — Guide de déploiement App Store & Play Store

## Architecture du projet

```
CodeQuest/
├── app/                          # Expo Router (navigation)
│   ├── _layout.tsx               # Root layout + fonts + purchases init
│   ├── index.tsx                 # Redirect onboarding/home
│   ├── onboarding.tsx            # Onboarding flow
│   ├── paywall.tsx               # Écran d'abonnement (modal)
│   ├── streak.tsx                # Streak detail (modal)
│   ├── (tabs)/
│   │   ├── _layout.tsx           # Tab bar navigation
│   │   ├── home.tsx              # Dashboard
│   │   ├── learn.tsx             # Liste des cours
│   │   ├── leaderboard.tsx       # Classement
│   │   └── profile.tsx           # Profil & paramètres
│   ├── course/[courseId].tsx     # Détail parcours (carte Duolingo)
│   └── lesson/[courseId]/[unitId]/[lessonId].tsx  # Moteur d'exercices
├── src/
│   ├── data/courses.ts           # Tout le contenu pédagogique
│   ├── store/useAppStore.ts      # État global (Zustand + AsyncStorage)
│   ├── services/
│   │   ├── subscriptions.ts      # RevenueCat (IAP iOS + Android)
│   │   └── notifications.ts     # Push notifications (Expo)
│   ├── screens/                  # Composants écrans
│   └── utils/theme.ts            # Design tokens (couleurs, fonts, spacing)
├── app.json                      # Config Expo (bundle ID, permissions...)
└── eas.json                      # EAS Build & Submit config
```

---

## 💰 Modèle de monétisation

### Plans d'abonnement (via RevenueCat)
| Plan | Prix suggéré | Renouvellement |
|------|-------------|----------------|
| Mensuel | 4,99 €/mois | Automatique |
| Annuel | 29,99 €/an (50% off) | Automatique |
| À vie | 79,99 € | Unique |

### Consommables (optionnels)
| Article | Prix | Usage |
|---------|------|-------|
| Streak Freeze | 0,99 € | Protège le streak 1 jour |
| XP Boost 7j | 1,99 € | Double XP pendant 7 jours |

### Freemium gate
- **Gratuit** : Unités 1 de Python + HTML (~15 leçons)
- **Pro** : Tout débloqué (unités 2, 3, projets, certifs)

---

## ⚙️ Installation & démarrage

```bash
# 1. Cloner et installer
cd CodeQuest
npm install

# 2. Démarrer en développement
npx expo start

# 3. Tester sur device
npx expo start --ios      # iOS Simulator
npx expo start --android  # Android Emulator
```

---

## 📱 Déploiement — Étape par étape

### Prérequis
- [ ] Compte Apple Developer (99 $/an) → developer.apple.com
- [ ] Compte Google Play Console (25 $ unique) → play.google.com/console
- [ ] Compte RevenueCat (gratuit jusqu'à 2500$/mois MRR) → revenuecat.com
- [ ] Compte EAS (Expo Application Services) → expo.dev

---

### ÉTAPE 1 — Configurer RevenueCat (In-App Purchases)

```
1. Créer un compte sur revenuecat.com
2. Créer un nouveau projet "CodeQuest"
3. Ajouter une app iOS → noter l'API Key iOS
4. Ajouter une app Android → noter l'API Key Android
5. Créer les produits dans App Store Connect et Google Play Console
   - codequest_premium_monthly
   - codequest_premium_yearly
   - codequest_premium_lifetime
   - codequest_streak_freeze
6. Importer les produits dans RevenueCat
7. Créer un Entitlement "premium"
8. Créer une Offering "default" avec les 3 packages
```

Mettre à jour dans `app.json` :
```json
"revenueCatApiKeyIos": "appl_XXXXXXXXXX",
"revenueCatApiKeyAndroid": "goog_XXXXXXXXXX"
```

---

### ÉTAPE 2 — Configurer EAS Build

```bash
# Installer EAS CLI
npm install -g eas-cli

# Connexion
eas login

# Initialiser le projet
eas init

# Générer les credentials automatiquement
eas credentials
```

Mettre à jour dans `eas.json` :
```json
"projectId": "VOTRE_EAS_PROJECT_ID"
```

---

### ÉTAPE 3 — App Store (iOS)

#### 3a. Créer l'app dans App Store Connect
1. Aller sur appstoreconnect.apple.com
2. **Mes apps** → **+** → **Nouvelle app**
3. Remplir :
   - Nom : CodeQuest
   - Bundle ID : com.codequest.app
   - SKU : codequest-001
   - Langue principale : Français

#### 3b. Créer les produits In-App Purchase
1. Fonctionnalités → Achats intégrés → **+**
2. Créer chaque produit (IDs dans `src/services/subscriptions.ts`)
3. Soumettre pour review Apple

#### 3c. Remplir les métadonnées App Store
```
Nom de l'app : CodeQuest — Apprends à coder
Sous-titre : Python & HTML, niveau par niveau
Description :
  Apprends à programmer avec CodeQuest, l'app qui transforme le code 
  en aventure quotidienne. Comme Duolingo, mais pour devenir développeur !
  
  🐍 Python — Du print() aux fonctions avancées
  🌐 HTML — Structure et formulaires web
  🔥 Streaks quotidiens pour créer l'habitude
  ⚡ Exercices interactifs (fill-in, QCM, debugging)
  🏆 Classement hebdomadaire
  ⭐ CodeQuest Pro — Tout débloquer

Mots-clés (100 chars max) :
  coder,python,html,apprendre,développeur,programmation,cours,code,duolingo,mimo

Catégorie : Éducation
Catégorie secondaire : Productivité

URL de support : https://codequest.app/support
URL de confidentialité : https://codequest.app/privacy
URL marketing : https://codequest.app
```

#### 3d. Screenshots requis
- iPhone 6.9" (iPhone 15 Pro Max) : 1320 × 2868 px — **6 obligatoires**
- iPhone 6.5" (iPhone 14 Plus) : 1242 × 2688 px
- iPad Pro 13" : 2064 × 2752 px (si supporté)

#### 3e. Build et soumission iOS
```bash
# Build production iOS
eas build --platform ios --profile production

# Soumettre à App Store Connect
eas submit --platform ios --profile production
```

---

### ÉTAPE 4 — Play Store (Android)

#### 4a. Créer l'app dans Google Play Console
1. Aller sur play.google.com/console
2. **Créer une application**
3. Nom : CodeQuest
4. Package : com.codequest.app

#### 4b. Remplir le Store Listing
```
Titre (30 chars) : CodeQuest — Apprends à coder
Description courte (80 chars) : Apprends Python & HTML comme Duolingo, en 5 min/jour
Description longue (4000 chars) : [même que App Store]

Catégorie : Éducation
Tags : apprentissage, programmation, code, développement
```

#### 4c. Screenshots Android requis
- Téléphone : min 2, max 8 captures (16:9 ou 9:16)
- Tablette 7" et 10" (recommandé)
- Feature Graphic : 1024 × 500 px (obligatoire)

#### 4d. Service account pour EAS Submit
```bash
# Dans Google Play Console → Configuration → Accès API
# Créer un service account → télécharger JSON
# Placer dans : ./google-play-service-account.json
```

#### 4e. Build et soumission Android
```bash
# Build AAB production
eas build --platform android --profile production

# Soumettre en test interne d'abord
eas submit --platform android --profile production
# → Track: internal (puis alpha → beta → production)
```

---

### ÉTAPE 5 — Push Notifications

```bash
# Configurer dans Expo
eas push:android:upload --token your-fcm-key
```

Dans Google Firebase Console :
1. Créer projet CodeQuest
2. Ajouter app Android → télécharger `google-services.json`
3. Placer à la racine du projet

---

### ÉTAPE 6 — Politique de confidentialité (OBLIGATOIRE)

Héberger sur votre domaine :
- `https://codequest.app/privacy` — Politique de confidentialité
- `https://codequest.app/terms` — CGU

**Points obligatoires à mentionner :**
- Données collectées (progression, prénom, usage)
- Usage des notifications push
- Abonnements et annulation
- Conformité RGPD (droit de suppression)
- Pas de partage avec tiers (sauf RevenueCat/Expo)

**Générateur gratuit :** termly.io ou privacypolicygenerator.info

---

### ÉTAPE 7 — ASO (App Store Optimization)

#### Recherche de mots-clés (outils gratuits)
- AppFollow.io
- Sensor Tower (version gratuite)
- AppTweak

#### Stratégie de lancement
```
Semaine 1 : Lancer en "Accès anticipé" sur Android (pas de review)
Semaine 2 : Collecter avis, corriger bugs
Semaine 3 : Soumettre iOS (review 1-3 jours)
Semaine 4 : Lancer officiellement, campagne réseaux sociaux
```

---

## 📊 Analytics & Revenus — Configuration recommandée

```
RevenueCat Dashboard → Suivi MRR, churn, LTV
Expo Analytics     → Crashes, sessions
Mixpanel (gratuit) → Funnel onboarding → paywall → achat
```

### KPIs à suivre
| Métrique | Objectif mois 1 | Objectif mois 3 |
|----------|----------------|----------------|
| Téléchargements | 500 | 5 000 |
| D7 Retention | 20% | 30% |
| Conversion free→pro | 2% | 5% |
| MRR | 100 € | 1 000 € |

---

## 🔧 Checklist avant soumission

### Technique
- [ ] Tester sur iPhone SE (petit écran) et iPhone 15 Pro Max
- [ ] Tester sur Android 10, 12, 14
- [ ] Vérifier tous les flux d'achat en sandbox
- [ ] Tester restauration d'achats
- [ ] Vérifier les notifications push (device réel)
- [ ] Deep links fonctionnels
- [ ] Mode hors-ligne (leçons déjà chargées)

### App Store Review Guidelines
- [ ] Pas de dark patterns dans le paywall
- [ ] Bouton "Restaurer mes achats" visible
- [ ] Liens privacy policy et CGU actifs
- [ ] Pricing clairement affiché avant l'achat
- [ ] Possibilité de s'abonner SANS se connecter (guest mode)

### RGPD (Europe)
- [ ] Tracking Transparency prompt (iOS 14.5+)
- [ ] Possibilité de supprimer son compte et données
- [ ] Consentement notifications explicite

---

## 💡 Prochaines fonctionnalités pour augmenter les revenus

1. **CSS & JavaScript** — nouveaux parcours payants
2. **Projets guidés** — build a real app (pro only)
3. **Certificats** — PDF téléchargeables (pro only)
4. **Mode hors-ligne** — sync quand réseau disponible
5. **Famille/Équipe** — partage entre 2-6 personnes
6. **Backend avec Supabase** — leaderboard réel, sync multi-device
7. **IA Tutor** — Claude API pour expliquer les erreurs
8. **Referral program** — 1 mois pro offert par parrainage

---

## 🛠️ Stack technique complète

| Couche | Technologie | Pourquoi |
|--------|-------------|----------|
| Framework | Expo SDK 51 + React Native | Cross-platform, OTA updates |
| Navigation | Expo Router v3 | File-based, deep linking natif |
| État | Zustand + AsyncStorage | Simple, performant, persistant |
| IAP | RevenueCat | Gère StoreKit + Play Billing |
| Push | Expo Notifications | Abstraction iOS/Android |
| Build | EAS Build | CI/CD cloud, signing auto |
| Fonts | Syne + JetBrains Mono | Design premium |
| Animations | React Native Animated | Sans dépendance lourde |

---

*CodeQuest — Apprends à coder, un jour à la fois 🔥*
