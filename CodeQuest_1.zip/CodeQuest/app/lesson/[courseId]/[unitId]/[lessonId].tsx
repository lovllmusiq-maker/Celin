// app/lesson/[courseId]/[unitId]/[lessonId].tsx
export { default } from '../../../src/screens/LessonScreen';
