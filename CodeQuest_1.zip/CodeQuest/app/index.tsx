// app/index.tsx
import { Redirect } from 'expo-router';
import { useAppStore } from '../src/store/useAppStore';

export default function Index() {
  const { hasCompletedOnboarding } = useAppStore();
  return <Redirect href={hasCompletedOnboarding ? '/(tabs)/home' : '/onboarding'} />;
}
