// app/streak.tsx
import React from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { useAppStore } from '../src/store/useAppStore';
import { COLORS, FONTS, RADIUS, SPACING } from '../src/utils/theme';

export default function StreakScreen() {
  const { streak, isPremium, useFreezeStreak } = useAppStore();

  const handleUseFreeze = () => {
    if (streak.frozenCount <= 0) {
      Alert.alert(
        '🧊 Pas de Streak Freeze',
        'Tu peux acheter des Streak Freezes dans CodeQuest Pro !',
        [
          { text: 'Annuler', style: 'cancel' },
          { text: 'Voir Pro', onPress: () => router.push('/paywall') },
        ]
      );
      return;
    }
    Alert.alert(
      '🧊 Utiliser un Streak Freeze ?',
      `Il te reste ${streak.frozenCount} Streak Freeze(s). En utiliser un protégera ton streak d'hier.`,
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Utiliser',
          onPress: () => {
            const used = useFreezeStreak();
            if (used) Alert.alert('✅ Streak sauvé !', 'Ton streak a été protégé.');
          },
        },
      ]
    );
  };

  const MILESTONES = [3, 7, 14, 30, 60, 100, 200, 365];

  return (
    <LinearGradient colors={['#1A0800', '#080C14']} style={{ flex: 1 }}>
      <SafeAreaView style={{ flex: 1 }}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.closeBtn}>
            <Text style={styles.closeTxt}>✕</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Mon Streak</Text>
          <View style={{ width: 36 }} />
        </View>

        <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
          {/* Main streak display */}
          <View style={styles.streakHero}>
            <Text style={styles.streakFire}>🔥</Text>
            <Text style={styles.streakCount}>{streak.current}</Text>
            <Text style={styles.streakLabel}>jours consécutifs</Text>
            <Text style={styles.streakRecord}>Record : {streak.longest} jours</Text>
          </View>

          {/* Freeze tokens */}
          <View style={styles.freezeCard}>
            <View style={styles.freezeRow}>
              <Text style={styles.freezeTitle}>🧊 Streak Freezes</Text>
              <View style={styles.freezeCount}>
                <Text style={styles.freezeCountText}>{streak.frozenCount}</Text>
              </View>
            </View>
            <Text style={styles.freezeDesc}>
              Un Streak Freeze te protège si tu rates une journée.
              {isPremium ? '' : '\nDisponibles avec CodeQuest Pro.'}
            </Text>
            <TouchableOpacity
              onPress={handleUseFreeze}
              style={[styles.freezeBtn, streak.frozenCount === 0 && styles.freezeBtnDisabled]}
            >
              <Text style={styles.freezeBtnText}>
                {streak.frozenCount > 0 ? '🧊 Utiliser un Freeze' : '⭐ Obtenir des Freezes'}
              </Text>
            </TouchableOpacity>
          </View>

          {/* Milestones */}
          <Text style={styles.milestonesTitle}>Paliers de streak</Text>
          <View style={styles.milestones}>
            {MILESTONES.map((m) => {
              const reached = streak.longest >= m;
              const isCurrent = streak.current >= m && (streak.current < (MILESTONES[MILESTONES.indexOf(m) + 1] ?? 9999));
              return (
                <View key={m} style={[styles.milestone, reached && styles.milestoneReached, isCurrent && styles.milestoneCurrent]}>
                  <Text style={styles.milestoneDays}>{m}j</Text>
                  <Text style={styles.milestoneEmoji}>
                    {reached ? (m >= 100 ? '💎' : m >= 30 ? '🏅' : '✓') : '○'}
                  </Text>
                </View>
              );
            })}
          </View>

          {/* Tips */}
          <View style={styles.tipsCard}>
            <Text style={styles.tipsTitle}>💡 Conseils pour garder ton streak</Text>
            {[
              'Active les rappels quotidiens dans les paramètres',
              'Fais au moins 1 leçon courte les jours chargés',
              'Stocke des Streak Freezes pour les urgences',
              'Code à la même heure chaque jour pour créer l\'habitude',
            ].map((tip, i) => (
              <View key={i} style={styles.tip}>
                <Text style={styles.tipBullet}>›</Text>
                <Text style={styles.tipText}>{tip}</Text>
              </View>
            ))}
          </View>

          <View style={{ height: 40 }} />
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: SPACING.lg, paddingVertical: SPACING.md,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  closeBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: COLORS.bgCard, alignItems: 'center', justifyContent: 'center' },
  closeTxt: { color: COLORS.text, fontSize: 15 },
  headerTitle: { fontFamily: FONTS.bold, fontSize: 17, color: COLORS.text },
  content: { padding: SPACING.lg },
  streakHero: { alignItems: 'center', paddingVertical: SPACING.xl },
  streakFire: { fontSize: 72, marginBottom: SPACING.xs },
  streakCount: { fontFamily: FONTS.black, fontSize: 72, color: COLORS.warning, lineHeight: 80 },
  streakLabel: { fontFamily: FONTS.bold, fontSize: 20, color: COLORS.text, marginTop: SPACING.xs },
  streakRecord: { fontFamily: FONTS.regular, fontSize: 14, color: COLORS.textMuted, marginTop: SPACING.sm },
  freezeCard: {
    backgroundColor: 'rgba(59,130,246,0.1)', borderRadius: RADIUS.lg,
    padding: SPACING.lg, marginBottom: SPACING.lg,
    borderWidth: 1, borderColor: 'rgba(59,130,246,0.2)',
  },
  freezeRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: SPACING.sm },
  freezeTitle: { fontFamily: FONTS.bold, fontSize: 16, color: COLORS.text },
  freezeCount: {
    backgroundColor: COLORS.python, width: 32, height: 32,
    borderRadius: 16, alignItems: 'center', justifyContent: 'center',
  },
  freezeCountText: { fontFamily: FONTS.black, fontSize: 16, color: '#fff' },
  freezeDesc: { fontFamily: FONTS.regular, fontSize: 13, color: COLORS.textMuted, lineHeight: 20, marginBottom: SPACING.md },
  freezeBtn: {
    backgroundColor: 'rgba(59,130,246,0.2)', borderRadius: RADIUS.md,
    padding: SPACING.sm, alignItems: 'center', borderWidth: 1, borderColor: COLORS.python + '40',
  },
  freezeBtnDisabled: { opacity: 0.5 },
  freezeBtnText: { fontFamily: FONTS.bold, fontSize: 14, color: COLORS.python },
  milestonesTitle: { fontFamily: FONTS.bold, fontSize: 16, color: COLORS.text, marginBottom: SPACING.md },
  milestones: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.sm, marginBottom: SPACING.xl },
  milestone: {
    flex: 1, minWidth: 64, backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md,
    padding: SPACING.sm, alignItems: 'center', borderWidth: 1, borderColor: COLORS.border,
  },
  milestoneReached: { backgroundColor: 'rgba(34,197,94,0.12)', borderColor: COLORS.success + '40' },
  milestoneCurrent: { backgroundColor: 'rgba(245,158,11,0.15)', borderColor: COLORS.warning + '50' },
  milestoneDays: { fontFamily: FONTS.bold, fontSize: 13, color: COLORS.text },
  milestoneEmoji: { fontSize: 18, marginTop: 2 },
  tipsCard: {
    backgroundColor: COLORS.bgCard, borderRadius: RADIUS.lg,
    padding: SPACING.lg, borderWidth: 1, borderColor: COLORS.border,
  },
  tipsTitle: { fontFamily: FONTS.bold, fontSize: 15, color: COLORS.text, marginBottom: SPACING.md },
  tip: { flexDirection: 'row', gap: SPACING.sm, marginBottom: SPACING.sm },
  tipBullet: { fontFamily: FONTS.bold, fontSize: 16, color: COLORS.python },
  tipText: { fontFamily: FONTS.regular, fontSize: 13, color: COLORS.textMuted, flex: 1, lineHeight: 20 },
});
