// app/onboarding.tsx
export { default } from '../src/screens/OnboardingScreen';
