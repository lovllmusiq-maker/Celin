// app/paywall.tsx
export { default } from '../src/screens/PaywallScreen';
