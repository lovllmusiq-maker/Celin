// app/(tabs)/learn.tsx
import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { COURSES } from '../../src/data/courses';
import { useAppStore } from '../../src/store/useAppStore';
import { COLORS, FONTS, RADIUS, SPACING } from '../../src/utils/theme';

export default function LearnScreen() {
  const { lessonProgress, isPremium } = useAppStore();

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <SafeAreaView edges={['top']} style={{ backgroundColor: COLORS.bg }}>
        <View style={styles.header}>
          <Text style={styles.title}>Apprendre</Text>
          {!isPremium && (
            <TouchableOpacity onPress={() => router.push('/paywall')} style={styles.unlockBtn}>
              <LinearGradient colors={['#8B5CF6', '#6D28D9']} style={styles.unlockGrad}>
                <Text style={styles.unlockText}>⭐ Débloquer tout</Text>
              </LinearGradient>
            </TouchableOpacity>
          )}
        </View>
      </SafeAreaView>

      <ScrollView contentContainerStyle={{ padding: SPACING.lg }} showsVerticalScrollIndicator={false}>
        {Object.values(COURSES).map(course => (
          <View key={course.id} style={styles.courseSection}>
            <View style={styles.courseSectionHeader}>
              <Text style={styles.courseHeaderIcon}>{course.icon}</Text>
              <View>
                <Text style={styles.courseHeaderName}>{course.label}</Text>
                <Text style={styles.courseHeaderTag}>{course.tagline}</Text>
              </View>
            </View>

            {course.units.map((unit, ui) => {
              const unitDone = unit.lessons.filter(l => lessonProgress[l.id]?.completed).length;
              const isUnitLocked = !isPremium && ui > 0 &&
                course.units[ui - 1].lessons.some(l => !lessonProgress[l.id]?.completed);

              return (
                <View key={unit.id} style={styles.unitBlock}>
                  <View style={[styles.unitHeader, { borderLeftColor: unit.color }]}>
                    <Text style={styles.unitIcon}>{isUnitLocked ? '🔒' : unit.icon}</Text>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.unitName}>{unit.title}</Text>
                      <Text style={styles.unitProgress}>{unitDone}/{unit.lessons.length} leçons</Text>
                    </View>
                  </View>

                  {unit.lessons.map((lesson, li) => {
                    const done = lessonProgress[lesson.id]?.completed;
                    const stars = lessonProgress[lesson.id]?.stars ?? 0;
                    const isLocked = isUnitLocked ||
                      (!isPremium && lesson.isPremium);

                    return (
                      <TouchableOpacity
                        key={lesson.id}
                        onPress={() => {
                          if (isLocked) { router.push('/paywall'); return; }
                          router.push(`/lesson/${course.id}/${unit.id}/${lesson.id}`);
                        }}
                        activeOpacity={0.85}
                        style={[styles.lessonRow, done && styles.lessonDone, isLocked && styles.lessonLocked]}
                      >
                        <View style={[styles.lessonDot, done && { backgroundColor: unit.color }, isLocked && { backgroundColor: COLORS.bgElevated }]}>
                          <Text style={{ fontSize: 14 }}>
                            {isLocked ? '🔒' : done ? '✓' : '▶'}
                          </Text>
                        </View>
                        <View style={{ flex: 1 }}>
                          <Text style={[styles.lessonName, isLocked && { color: COLORS.textMuted }]}>
                            {lesson.title}
                          </Text>
                          <Text style={styles.lessonSub}>
                            {lesson.exercises.length} exercices · {lesson.exercises.reduce((a, e) => a + e.xp, 0)} XP
                          </Text>
                        </View>
                        {done && (
                          <View style={styles.starsRow}>
                            {[1, 2, 3].map(i => (
                              <Text key={i} style={{ fontSize: 12, opacity: i <= stars ? 1 : 0.2 }}>⭐</Text>
                            ))}
                          </View>
                        )}
                        {isLocked && !done && (
                          <View style={styles.premiumPill}>
                            <Text style={styles.premiumPillText}>Pro</Text>
                          </View>
                        )}
                      </TouchableOpacity>
                    );
                  })}
                </View>
              );
            })}
          </View>
        ))}
        <View style={{ height: 100 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: SPACING.lg, paddingVertical: SPACING.md,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  title: { fontFamily: FONTS.black, fontSize: 24, color: COLORS.text },
  unlockBtn: { borderRadius: RADIUS.full, overflow: 'hidden' },
  unlockGrad: { paddingHorizontal: 14, paddingVertical: 7 },
  unlockText: { fontFamily: FONTS.bold, fontSize: 13, color: '#fff' },
  courseSection: { marginBottom: SPACING.xl },
  courseSectionHeader: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.sm, marginBottom: SPACING.md,
  },
  courseHeaderIcon: { fontSize: 32 },
  courseHeaderName: { fontFamily: FONTS.black, fontSize: 20, color: COLORS.text },
  courseHeaderTag: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted },
  unitBlock: { marginBottom: SPACING.md },
  unitHeader: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.sm,
    paddingLeft: SPACING.sm, borderLeftWidth: 3, marginBottom: SPACING.sm,
  },
  unitIcon: { fontSize: 20 },
  unitName: { fontFamily: FONTS.bold, fontSize: 15, color: COLORS.text },
  unitProgress: { fontFamily: FONTS.regular, fontSize: 11, color: COLORS.textMuted },
  lessonRow: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.sm,
    backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md,
    padding: SPACING.md, marginBottom: 8,
    borderWidth: 1, borderColor: COLORS.border,
  },
  lessonDone: { borderColor: 'rgba(34,197,94,0.2)', backgroundColor: 'rgba(34,197,94,0.05)' },
  lessonLocked: { opacity: 0.6 },
  lessonDot: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: COLORS.bgElevated, alignItems: 'center', justifyContent: 'center',
  },
  lessonName: { fontFamily: FONTS.semibold, fontSize: 14, color: COLORS.text },
  lessonSub: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted, marginTop: 2 },
  starsRow: { flexDirection: 'row', gap: 2 },
  premiumPill: {
    backgroundColor: COLORS.premium + '30', paddingHorizontal: 8, paddingVertical: 3,
    borderRadius: RADIUS.full, borderWidth: 1, borderColor: COLORS.premium + '50',
  },
  premiumPillText: { fontFamily: FONTS.bold, fontSize: 10, color: COLORS.premiumLight },
});
