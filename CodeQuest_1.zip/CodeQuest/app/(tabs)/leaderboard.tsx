// app/(tabs)/leaderboard.tsx
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppStore } from '../../src/store/useAppStore';
import { COLORS, FONTS, RADIUS, SPACING } from '../../src/utils/theme';

// Mock leaderboard data (in production: fetch from your backend / Supabase)
const MOCK_PLAYERS = [
  { rank: 1, name: 'SophieCode', avatar: '👩‍💻', xp: 3850, streak: 42, country: '🇫🇷' },
  { rank: 2, name: 'DevMaster', avatar: '🧙', xp: 3420, streak: 28, country: '🇧🇪' },
  { rank: 3, name: 'PyQueen', avatar: '🐍', xp: 2980, streak: 17, country: '🇨🇦' },
  { rank: 4, name: 'HTMLHero', avatar: '🦸', xp: 2540, streak: 9, country: '🇸🇳' },
  { rank: 5, name: 'NightCoder', avatar: '🌙', xp: 2210, streak: 14, country: '🇲🇦' },
  { rank: 6, name: 'AlgoKing', avatar: '👑', xp: 1980, streak: 6, country: '🇨🇮' },
  { rank: 7, name: 'ByteWitch', avatar: '🔮', xp: 1750, streak: 21, country: '🇫🇷' },
  { rank: 8, name: 'CodeRobot', avatar: '🤖', xp: 1540, streak: 3, country: '🇩🇿' },
  { rank: 9, name: 'PixelGuru', avatar: '🎨', xp: 1320, streak: 8, country: '🇧🇯' },
  { rank: 10, name: 'LoopLord', avatar: '🔄', xp: 1100, streak: 5, country: '🇫🇷' },
];

const TABS = ['Cette semaine', 'Ce mois', 'Tous les temps'];

const RANK_COLORS = ['#FFD700', '#C0C0C0', '#CD7F32'];

export default function LeaderboardScreen() {
  const [tab, setTab] = useState(0);
  const { username, avatar, totalXp, streak } = useAppStore();

  // Insert current user
  const myRank = MOCK_PLAYERS.findIndex(p => p.xp < totalXp) + 1 || MOCK_PLAYERS.length + 1;
  const players = [...MOCK_PLAYERS];

  const top3 = players.slice(0, 3);
  const rest = players.slice(3);

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <SafeAreaView edges={['top']} style={{ backgroundColor: COLORS.bg }}>
        <View style={styles.header}>
          <Text style={styles.title}>🏆 Classement</Text>
        </View>

        {/* Tabs */}
        <View style={styles.tabs}>
          {TABS.map((t, i) => (
            <TouchableOpacity
              key={i}
              onPress={() => setTab(i)}
              style={[styles.tab, tab === i && styles.tabActive]}
            >
              <Text style={[styles.tabText, tab === i && styles.tabTextActive]}>{t}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </SafeAreaView>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Podium top 3 */}
        <LinearGradient
          colors={['rgba(251,191,36,0.1)', 'transparent']}
          style={styles.podium}
        >
          <View style={styles.podiumRow}>
            {/* 2nd */}
            <PodiumCard player={top3[1]} height={80} />
            {/* 1st */}
            <PodiumCard player={top3[0]} height={110} isFirst />
            {/* 3rd */}
            <PodiumCard player={top3[2]} height={60} />
          </View>
        </LinearGradient>

        {/* Rest of leaderboard */}
        <View style={styles.listContainer}>
          {rest.map((player) => (
            <PlayerRow key={player.rank} player={player} isMe={false} />
          ))}

          {/* My position */}
          <View style={styles.myPosSeparator}>
            <View style={styles.myPosDash} />
            <Text style={styles.myPosLabel}>Ma position</Text>
            <View style={styles.myPosDash} />
          </View>

          <PlayerRow
            player={{
              rank: myRank,
              name: username,
              avatar,
              xp: totalXp,
              streak: streak.current,
              country: '🌍',
            }}
            isMe
          />
        </View>

        {/* League info */}
        <View style={styles.leagueCard}>
          <Text style={styles.leagueTitle}>🥉 Ligue Bronze</Text>
          <Text style={styles.leagueText}>
            Les 10 meilleurs montent en Ligue Argent chaque semaine.
            Continue à t'entraîner pour progresser !
          </Text>
          <View style={styles.leagueProgress}>
            <LinearGradient
              colors={['#CD7F32', '#F59E0B']}
              style={[styles.leagueFill, { width: `${(totalXp / 5000) * 100}%` }]}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            />
          </View>
          <Text style={styles.leagueProgressText}>{totalXp} / 5000 XP pour la Ligue Argent</Text>
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>
    </View>
  );
}

function PodiumCard({ player, height, isFirst }: any) {
  const rankColor = RANK_COLORS[player.rank - 1];
  return (
    <View style={[styles.podiumCard, isFirst && styles.podiumCardFirst]}>
      <Text style={styles.podiumAvatar}>{player.avatar}</Text>
      <Text style={styles.podiumName} numberOfLines={1}>{player.name}</Text>
      <Text style={[styles.podiumXp, { color: rankColor }]}>{player.xp} XP</Text>
      <View style={[styles.podiumBase, { height, backgroundColor: rankColor + '30', borderTopColor: rankColor }]}>
        <Text style={[styles.podiumRankText, { color: rankColor }]}>
          {player.rank === 1 ? '🥇' : player.rank === 2 ? '🥈' : '🥉'}
        </Text>
      </View>
    </View>
  );
}

function PlayerRow({ player, isMe }: { player: any; isMe: boolean }) {
  const rankColor = player.rank <= 3 ? RANK_COLORS[player.rank - 1] : COLORS.textMuted;
  return (
    <View style={[styles.playerRow, isMe && styles.playerRowMe]}>
      <Text style={[styles.playerRank, { color: rankColor }]}>
        {player.rank <= 3 ? ['🥇', '🥈', '🥉'][player.rank - 1] : `#${player.rank}`}
      </Text>
      <Text style={styles.playerAvatar}>{player.avatar}</Text>
      <View style={{ flex: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Text style={[styles.playerName, isMe && { color: COLORS.python }]} numberOfLines={1}>
            {player.name}
          </Text>
          <Text style={{ fontSize: 12 }}>{player.country}</Text>
        </View>
        <Text style={styles.playerStreak}>🔥 {player.streak} jours</Text>
      </View>
      <Text style={[styles.playerXp, isMe && { color: COLORS.python }]}>
        {player.xp.toLocaleString()} XP
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: SPACING.lg, paddingVertical: SPACING.md,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  title: { fontFamily: FONTS.black, fontSize: 24, color: COLORS.text },
  tabs: {
    flexDirection: 'row', paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.sm, gap: SPACING.sm,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  tab: {
    paddingHorizontal: 14, paddingVertical: 7,
    borderRadius: RADIUS.full, backgroundColor: COLORS.bgCard,
    borderWidth: 1, borderColor: COLORS.border,
  },
  tabActive: { backgroundColor: COLORS.python, borderColor: COLORS.python },
  tabText: { fontFamily: FONTS.regular, fontSize: 13, color: COLORS.textMuted },
  tabTextActive: { color: '#fff', fontFamily: FONTS.bold },
  podium: { padding: SPACING.lg, paddingBottom: 0 },
  podiumRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'flex-end', gap: SPACING.sm },
  podiumCard: { flex: 1, alignItems: 'center', maxWidth: 120 },
  podiumCardFirst: { transform: [{ scale: 1.05 }] },
  podiumAvatar: { fontSize: 32, marginBottom: 4 },
  podiumName: { fontFamily: FONTS.bold, fontSize: 12, color: COLORS.text, textAlign: 'center' },
  podiumXp: { fontFamily: FONTS.bold, fontSize: 11, marginBottom: 6 },
  podiumBase: {
    width: '100%', borderTopWidth: 3,
    alignItems: 'center', justifyContent: 'center', borderRadius: 4,
    borderTopLeftRadius: 8, borderTopRightRadius: 8,
  },
  podiumRankText: { fontSize: 24, marginTop: 8 },
  listContainer: { padding: SPACING.lg, gap: SPACING.xs },
  playerRow: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.sm,
    backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md,
    padding: SPACING.md, borderWidth: 1, borderColor: COLORS.border,
  },
  playerRowMe: { borderColor: COLORS.python + '50', backgroundColor: 'rgba(59,130,246,0.08)' },
  playerRank: { fontFamily: FONTS.bold, fontSize: 14, width: 36, textAlign: 'center' },
  playerAvatar: { fontSize: 24 },
  playerName: { fontFamily: FONTS.bold, fontSize: 14, color: COLORS.text },
  playerStreak: { fontFamily: FONTS.regular, fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  playerXp: { fontFamily: FONTS.bold, fontSize: 13, color: COLORS.textMuted },
  myPosSeparator: { flexDirection: 'row', alignItems: 'center', gap: SPACING.sm, marginVertical: SPACING.sm },
  myPosDash: { flex: 1, height: 1, backgroundColor: COLORS.border },
  myPosLabel: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted },
  leagueCard: {
    margin: SPACING.lg, backgroundColor: COLORS.bgCard,
    borderRadius: RADIUS.lg, padding: SPACING.lg,
    borderWidth: 1, borderColor: 'rgba(205,127,50,0.3)',
  },
  leagueTitle: { fontFamily: FONTS.bold, fontSize: 16, color: COLORS.text, marginBottom: 6 },
  leagueText: { fontFamily: FONTS.regular, fontSize: 13, color: COLORS.textMuted, lineHeight: 20, marginBottom: SPACING.md },
  leagueProgress: { height: 8, backgroundColor: COLORS.bgElevated, borderRadius: 4, overflow: 'hidden', marginBottom: 6 },
  leagueFill: { height: '100%', borderRadius: 4 },
  leagueProgressText: { fontFamily: FONTS.regular, fontSize: 11, color: COLORS.textMuted },
});
