// app/admin.tsx
export { default } from '../src/screens/AdminDashboardScreen';
