// app/course/[courseId].tsx
import React from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { COURSES } from '../../src/data/courses';
import { useAppStore } from '../../src/store/useAppStore';
import { COLORS, FONTS, RADIUS, SPACING } from '../../src/utils/theme';

export default function CourseScreen() {
  const { courseId } = useLocalSearchParams<{ courseId: string }>();
  const course = COURSES[courseId];
  const { lessonProgress, isPremium } = useAppStore();

  if (!course) return null;

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      {/* Hero */}
      <LinearGradient
        colors={[course.color + '30', COLORS.bg]}
        style={styles.hero}
      >
        <SafeAreaView edges={['top']}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={styles.backText}>← Retour</Text>
          </TouchableOpacity>
          <View style={styles.heroContent}>
            <Text style={styles.heroIcon}>{course.icon}</Text>
            <Text style={styles.heroTitle}>{course.label}</Text>
            <Text style={styles.heroSub}>{course.description}</Text>
          </View>
        </SafeAreaView>
      </LinearGradient>

      <ScrollView contentContainerStyle={{ padding: SPACING.lg }} showsVerticalScrollIndicator={false}>
        {course.units.map((unit, ui) => {
          const prevUnit = course.units[ui - 1];
          const isLocked = ui > 0 && prevUnit.lessons.some(l => !lessonProgress[l.id]?.completed);
          const unitDone = unit.lessons.filter(l => lessonProgress[l.id]?.completed).length;

          return (
            <View key={unit.id} style={styles.unitBlock}>
              {/* Unit header */}
              <View style={[styles.unitHeader, { borderColor: isLocked ? COLORS.border : unit.color + '50', backgroundColor: isLocked ? COLORS.bgCard : unit.color + '12' }]}>
                <Text style={styles.unitIcon}>{isLocked ? '🔒' : unit.icon}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={styles.unitTitle}>{unit.title}</Text>
                  <Text style={styles.unitSub}>{unitDone}/{unit.lessons.length} leçons</Text>
                </View>
                <View style={styles.unitRing}>
                  <Text style={[styles.unitRingText, { color: unit.color }]}>
                    {Math.round((unitDone / unit.lessons.length) * 100)}%
                  </Text>
                </View>
              </View>

              {/* Lessons map (Duolingo-style vertical path) */}
              <View style={styles.lessonPath}>
                {unit.lessons.map((lesson, li) => {
                  const done = lessonProgress[lesson.id]?.completed;
                  const stars = lessonProgress[lesson.id]?.stars ?? 0;
                  const isLessonLocked = isLocked || (!isPremium && lesson.isPremium);
                  const xpTotal = lesson.exercises.reduce((a, e) => a + e.xp, 0);
                  const isEven = li % 2 === 0;

                  return (
                    <View key={lesson.id} style={[styles.lessonNode, isEven ? styles.lessonNodeLeft : styles.lessonNodeRight]}>
                      {/* Connector line */}
                      {li > 0 && <View style={[styles.connector, isEven ? styles.connectorRight : styles.connectorLeft]} />}

                      <TouchableOpacity
                        onPress={() => {
                          if (isLessonLocked) { router.push('/paywall'); return; }
                          router.push(`/lesson/${course.id}/${unit.id}/${lesson.id}`);
                        }}
                        activeOpacity={0.85}
                        style={[
                          styles.lessonBtn,
                          done && { backgroundColor: unit.color, borderColor: unit.color },
                          isLessonLocked && { opacity: 0.5 },
                        ]}
                      >
                        <Text style={styles.lessonBtnIcon}>
                          {isLessonLocked ? '🔒' : done ? '✓' : lesson.icon}
                        </Text>
                      </TouchableOpacity>

                      <View style={[styles.lessonInfo, isEven ? { alignItems: 'flex-start' } : { alignItems: 'flex-end' }]}>
                        <Text style={styles.lessonName}>{lesson.title}</Text>
                        <View style={styles.lessonMeta}>
                          {done && (
                            <View style={styles.starsRow}>
                              {[1, 2, 3].map(i => (
                                <Text key={i} style={{ fontSize: 10, opacity: i <= stars ? 1 : 0.2 }}>⭐</Text>
                              ))}
                            </View>
                          )}
                          {!done && <Text style={styles.lessonXp}>{xpTotal} XP</Text>}
                          {isLessonLocked && !done && (
                            <View style={styles.proPill}>
                              <Text style={styles.proPillText}>Pro</Text>
                            </View>
                          )}
                        </View>
                      </View>
                    </View>
                  );
                })}
              </View>
            </View>
          );
        })}
        <View style={{ height: 100 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  hero: { paddingBottom: SPACING.xl },
  backBtn: { paddingHorizontal: SPACING.lg, paddingTop: SPACING.md },
  backText: { fontFamily: FONTS.regular, fontSize: 14, color: COLORS.textMuted },
  heroContent: { padding: SPACING.lg, paddingTop: SPACING.sm },
  heroIcon: { fontSize: 56, marginBottom: SPACING.sm },
  heroTitle: { fontFamily: FONTS.black, fontSize: 32, color: COLORS.text },
  heroSub: { fontFamily: FONTS.regular, fontSize: 14, color: COLORS.textMuted, marginTop: 6, lineHeight: 22 },
  unitBlock: { marginBottom: SPACING.xl },
  unitHeader: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.sm,
    padding: SPACING.md, borderRadius: RADIUS.lg, borderWidth: 1, marginBottom: SPACING.lg,
  },
  unitIcon: { fontSize: 28 },
  unitTitle: { fontFamily: FONTS.bold, fontSize: 16, color: COLORS.text },
  unitSub: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted, marginTop: 2 },
  unitRing: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: COLORS.bgElevated,
    alignItems: 'center', justifyContent: 'center',
  },
  unitRingText: { fontFamily: FONTS.bold, fontSize: 12 },
  lessonPath: { paddingHorizontal: SPACING.sm },
  lessonNode: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.md,
    marginBottom: SPACING.lg,
  },
  lessonNodeLeft: { flexDirection: 'row' },
  lessonNodeRight: { flexDirection: 'row-reverse' },
  connector: {
    position: 'absolute', top: -SPACING.lg,
    width: 2, height: SPACING.lg, backgroundColor: COLORS.border,
  },
  connectorLeft: { left: 28 },
  connectorRight: { right: 28 },
  lessonBtn: {
    width: 60, height: 60, borderRadius: 30,
    backgroundColor: COLORS.bgCard, borderWidth: 2, borderColor: COLORS.border,
    alignItems: 'center', justifyContent: 'center',
  },
  lessonBtnIcon: { fontSize: 24 },
  lessonInfo: { flex: 1 },
  lessonName: { fontFamily: FONTS.bold, fontSize: 14, color: COLORS.text },
  lessonMeta: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 },
  lessonXp: { fontFamily: FONTS.regular, fontSize: 11, color: COLORS.textMuted },
  starsRow: { flexDirection: 'row', gap: 2 },
  proPill: {
    backgroundColor: COLORS.premium + '25', paddingHorizontal: 8, paddingVertical: 2,
    borderRadius: RADIUS.full, borderWidth: 1, borderColor: COLORS.premium + '40',
  },
  proPillText: { fontFamily: FONTS.bold, fontSize: 10, color: COLORS.premiumLight },
});
