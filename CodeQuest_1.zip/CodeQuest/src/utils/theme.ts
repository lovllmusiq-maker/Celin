// src/utils/theme.ts
export const COLORS = {
  bg: '#080C14',
  bgCard: '#0F172A',
  bgElevated: '#1A2035',
  border: 'rgba(255,255,255,0.08)',
  borderHover: 'rgba(255,255,255,0.15)',
  text: '#E2E8F0',
  textMuted: '#64748B',
  textFaint: '#334155',
  python: '#3B82F6',
  pythonLight: '#60A5FA',
  html: '#F97316',
  htmlLight: '#FB923C',
  css: '#A78BFA',
  js: '#FBBF24',
  success: '#22C55E',
  successDark: '#16A34A',
  danger: '#EF4444',
  dangerDark: '#DC2626',
  warning: '#F59E0B',
  gold: '#FBBF24',
  premium: '#8B5CF6',
  premiumLight: '#A78BFA',
};

export const FONTS = {
  black: 'Syne_900Black',
  bold: 'Syne_700Bold',
  semibold: 'Syne_600SemiBold',
  regular: 'Syne_400Regular',
  mono: 'JetBrainsMono_400Regular',
  monoBold: 'JetBrainsMono_700Bold',
};

export const RADIUS = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 999,
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const SHADOWS = {
  card: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
  glow: (color: string) => ({
    shadowColor: color,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 12,
  }),
};
