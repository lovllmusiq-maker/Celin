// src/store/useAppStore.ts
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface LessonProgress {
  completed: boolean;
  xpEarned: number;
  stars: number; // 1-3 stars
  completedAt: string;
  attempts: number;
}

export interface DailyStreak {
  current: number;
  longest: number;
  lastActivityDate: string | null;
  frozenCount: number; // streak freezes remaining
}

interface AppState {
  // User Profile
  userId: string;
  username: string;
  avatar: string;
  joinedAt: string;

  // Subscription
  isPremium: boolean;
  premiumExpiresAt: string | null;
  premiumPlan: 'monthly' | 'yearly' | null;

  // Progress
  lessonProgress: Record<string, LessonProgress>;
  totalXp: number;
  level: number;
  xpToNextLevel: number;

  // Streak
  streak: DailyStreak;

  // Daily Goal
  dailyGoal: number; // lessons
  dailyDone: number;
  lastDailyReset: string | null;

  // Stats
  totalLessonsCompleted: number;
  totalExercisesCompleted: number;
  totalCorrectAnswers: number;
  totalWrongAnswers: number;

  // Settings
  notifications: boolean;
  notificationTime: string; // HH:MM
  soundEffects: boolean;
  haptics: boolean;
  language: string;

  // Onboarding
  hasCompletedOnboarding: boolean;
  selectedGoal: 'casual' | 'regular' | 'serious' | 'intense';

  // Actions
  completeLesson: (lessonId: string, xp: number, stars: number) => void;
  updateStreak: () => void;
  setPremium: (plan: 'monthly' | 'yearly', expiresAt: string) => void;
  cancelPremium: () => void;
  setDailyGoal: (goal: number) => void;
  incrementDailyDone: () => void;
  resetDailyIfNeeded: () => void;
  setOnboarded: (goal: 'casual' | 'regular' | 'serious' | 'intense') => void;
  setUsername: (name: string) => void;
  setAvatar: (avatar: string) => void;
  toggleNotifications: (val: boolean) => void;
  setNotificationTime: (time: string) => void;
  toggleSound: (val: boolean) => void;
  toggleHaptics: (val: boolean) => void;
  useFreezeStreak: () => boolean;
  addFreezeStreak: () => void;
}

const LEVEL_XP_REQUIREMENTS = [
  0, 100, 250, 500, 900, 1400, 2000, 2800, 3800, 5000,
  6500, 8200, 10200, 12500, 15000,
];

function getLevelFromXp(xp: number): { level: number; xpToNext: number } {
  let level = 1;
  for (let i = 0; i < LEVEL_XP_REQUIREMENTS.length - 1; i++) {
    if (xp >= LEVEL_XP_REQUIREMENTS[i + 1]) level = i + 2;
    else break;
  }
  const currentLevelXp = LEVEL_XP_REQUIREMENTS[level - 1] || 0;
  const nextLevelXp = LEVEL_XP_REQUIREMENTS[level] || 99999;
  return { level, xpToNext: nextLevelXp - xp };
}

function todayStr() {
  return new Date().toISOString().split('T')[0];
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Initial state
      userId: `user_${Date.now()}`,
      username: 'Codeur',
      avatar: '🧑‍💻',
      joinedAt: new Date().toISOString(),

      isPremium: false,
      premiumExpiresAt: null,
      premiumPlan: null,

      lessonProgress: {},
      totalXp: 0,
      level: 1,
      xpToNextLevel: 100,

      streak: {
        current: 0,
        longest: 0,
        lastActivityDate: null,
        frozenCount: 0,
      },

      dailyGoal: 3,
      dailyDone: 0,
      lastDailyReset: null,

      totalLessonsCompleted: 0,
      totalExercisesCompleted: 0,
      totalCorrectAnswers: 0,
      totalWrongAnswers: 0,

      notifications: true,
      notificationTime: '20:00',
      soundEffects: true,
      haptics: true,
      language: 'fr',

      hasCompletedOnboarding: false,
      selectedGoal: 'regular',

      // ── Actions ──────────────────────────────────────────────
      completeLesson: (lessonId, xp, stars) => {
        const state = get();
        const prev = state.lessonProgress[lessonId];
        const isNew = !prev?.completed;
        const newXp = state.totalXp + (isNew ? xp : Math.floor(xp * 0.3));
        const { level, xpToNext } = getLevelFromXp(newXp);

        set({
          totalXp: newXp,
          level,
          xpToNextLevel: xpToNext,
          totalLessonsCompleted: isNew
            ? state.totalLessonsCompleted + 1
            : state.totalLessonsCompleted,
          lessonProgress: {
            ...state.lessonProgress,
            [lessonId]: {
              completed: true,
              xpEarned: isNew ? xp : Math.max(prev?.xpEarned ?? 0, xp),
              stars: Math.max(prev?.stars ?? 0, stars),
              completedAt: new Date().toISOString(),
              attempts: (prev?.attempts ?? 0) + 1,
            },
          },
        });
        get().updateStreak();
        get().incrementDailyDone();
      },

      updateStreak: () => {
        const state = get();
        const today = todayStr();
        const last = state.streak.lastActivityDate;

        if (last === today) return; // already counted today

        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const yesterdayStr = yesterday.toISOString().split('T')[0];

        let newCurrent = 1;
        if (last === yesterdayStr) {
          newCurrent = state.streak.current + 1;
        }

        set({
          streak: {
            ...state.streak,
            current: newCurrent,
            longest: Math.max(state.streak.longest, newCurrent),
            lastActivityDate: today,
          },
        });
      },

      setPremium: (plan, expiresAt) =>
        set({ isPremium: true, premiumPlan: plan, premiumExpiresAt: expiresAt }),

      cancelPremium: () =>
        set({ isPremium: false, premiumPlan: null, premiumExpiresAt: null }),

      setDailyGoal: (goal) => set({ dailyGoal: goal }),

      incrementDailyDone: () => {
        const state = get();
        get().resetDailyIfNeeded();
        set({ dailyDone: state.dailyDone + 1 });
      },

      resetDailyIfNeeded: () => {
        const state = get();
        const today = todayStr();
        if (state.lastDailyReset !== today) {
          set({ dailyDone: 0, lastDailyReset: today });
        }
      },

      setOnboarded: (goal) => {
        const goalToLessons = { casual: 1, regular: 3, serious: 5, intense: 10 };
        set({
          hasCompletedOnboarding: true,
          selectedGoal: goal,
          dailyGoal: goalToLessons[goal],
        });
      },

      setUsername: (name) => set({ username: name }),
      setAvatar: (avatar) => set({ avatar }),
      toggleNotifications: (val) => set({ notifications: val }),
      setNotificationTime: (time) => set({ notificationTime: time }),
      toggleSound: (val) => set({ soundEffects: val }),
      toggleHaptics: (val) => set({ haptics: val }),

      useFreezeStreak: () => {
        const state = get();
        if (state.streak.frozenCount <= 0) return false;
        set({
          streak: {
            ...state.streak,
            frozenCount: state.streak.frozenCount - 1,
            lastActivityDate: todayStr(),
          },
        });
        return true;
      },

      addFreezeStreak: () => {
        const state = get();
        set({
          streak: {
            ...state.streak,
            frozenCount: state.streak.frozenCount + 1,
          },
        });
      },
    }),
    {
      name: 'codequest-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);
