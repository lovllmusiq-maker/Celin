// src/services/subscriptions.ts
// Uses RevenueCat (react-native-purchases) - the industry standard for in-app purchases
// Handles StoreKit (iOS) and Google Play Billing (Android) automatically

import Purchases, {
  PurchasesPackage,
  CustomerInfo,
  LOG_LEVEL,
} from 'react-native-purchases';
import { Platform } from 'react-native';
import Constants from 'expo-constants';
import { useAppStore } from '../store/useAppStore';

// ── Product IDs (must match App Store Connect & Google Play Console) ─────────
export const PRODUCT_IDS = {
  MONTHLY: 'codequest_premium_monthly',   // €4.99/month
  YEARLY: 'codequest_premium_yearly',     // €29.99/year (50% off)
  LIFETIME: 'codequest_premium_lifetime', // €79.99 one-time
  STREAK_FREEZE: 'codequest_streak_freeze', // €0.99 consumable
  XP_BOOST: 'codequest_xp_boost_7d',     // €1.99 consumable (7 days)
};

export const ENTITLEMENT_ID = 'premium';

// ── Initialization ────────────────────────────────────────────────────────────
export async function initializePurchases() {
  try {
    if (__DEV__) {
      Purchases.setLogLevel(LOG_LEVEL.DEBUG);
    }

    const apiKey =
      Platform.OS === 'ios'
        ? Constants.expoConfig?.extra?.revenueCatApiKeyIos
        : Constants.expoConfig?.extra?.revenueCatApiKeyAndroid;

    if (!apiKey) {
      console.warn('[Purchases] No RevenueCat API key found');
      return;
    }

    await Purchases.configure({ apiKey });

    // Restore on launch
    const customerInfo = await Purchases.getCustomerInfo();
    handleCustomerInfo(customerInfo);
  } catch (e) {
    console.error('[Purchases] init error', e);
  }
}

// ── Fetch available packages ──────────────────────────────────────────────────
export async function fetchOfferings(): Promise<PurchasesPackage[]> {
  try {
    const offerings = await Purchases.getOfferings();
    if (offerings.current) {
      return offerings.current.availablePackages;
    }
    return [];
  } catch (e) {
    console.error('[Purchases] fetchOfferings error', e);
    return [];
  }
}

// ── Purchase a package ────────────────────────────────────────────────────────
export async function purchasePackage(
  pkg: PurchasesPackage
): Promise<{ success: boolean; error?: string }> {
  try {
    const { customerInfo } = await Purchases.purchasePackage(pkg);
    handleCustomerInfo(customerInfo);
    return { success: true };
  } catch (e: any) {
    if (!e.userCancelled) {
      return { success: false, error: e.message };
    }
    return { success: false, error: 'cancelled' };
  }
}

// ── Restore purchases ─────────────────────────────────────────────────────────
export async function restorePurchases(): Promise<boolean> {
  try {
    const customerInfo = await Purchases.restorePurchases();
    return handleCustomerInfo(customerInfo);
  } catch (e) {
    console.error('[Purchases] restore error', e);
    return false;
  }
}

// ── Handle customer info update ───────────────────────────────────────────────
function handleCustomerInfo(info: CustomerInfo): boolean {
  const store = useAppStore.getState();
  const isPremium =
    typeof info.entitlements.active[ENTITLEMENT_ID] !== 'undefined';

  if (isPremium) {
    const entitlement = info.entitlements.active[ENTITLEMENT_ID];
    const expiresAt = entitlement.expirationDate ?? null;
    const plan = entitlement.productIdentifier?.includes('yearly')
      ? 'yearly'
      : 'monthly';
    store.setPremium(plan, expiresAt ?? new Date(Date.now() + 31536000000).toISOString());
  } else {
    if (store.isPremium) store.cancelPremium();
  }

  return isPremium;
}

// ── Pricing display helpers ───────────────────────────────────────────────────
export interface PlanInfo {
  id: string;
  title: string;
  price: string;
  period: string;
  monthlyPrice: string;
  savings?: string;
  isPopular?: boolean;
  color: string;
  features: string[];
}

export const PLAN_DISPLAY: PlanInfo[] = [
  {
    id: PRODUCT_IDS.MONTHLY,
    title: 'Mensuel',
    price: '4,99 €',
    period: '/mois',
    monthlyPrice: '4,99 €/mois',
    color: '#3B82F6',
    features: [
      'Accès à toutes les leçons',
      'Exercices avancés illimités',
      'Projets pratiques',
      'Sans publicité',
    ],
  },
  {
    id: PRODUCT_IDS.YEARLY,
    title: 'Annuel',
    price: '29,99 €',
    period: '/an',
    monthlyPrice: '2,50 €/mois',
    savings: 'Économise 50%',
    isPopular: true,
    color: '#8B5CF6',
    features: [
      'Tout du plan mensuel',
      '2 Streak Freezes offerts',
      'Certificat de complétion',
      'Accès prioritaire aux nouveautés',
    ],
  },
  {
    id: PRODUCT_IDS.LIFETIME,
    title: 'À vie',
    price: '79,99 €',
    period: 'une fois',
    monthlyPrice: 'Paiement unique',
    savings: 'Meilleure valeur',
    color: '#F59E0B',
    features: [
      'Tout, pour toujours',
      '5 Streak Freezes offerts',
      'Badge exclusif "Fondateur"',
      'Toutes les futures langues',
    ],
  },
];

// ── Premium features gate ─────────────────────────────────────────────────────
export function isPremiumContent(lessonId: string): boolean {
  // Logic: free users get first 2 units of each course, then paywall
  const premiumLessonPrefixes = [
    'py-u2-l2', 'py-u2-l3', 'py-u3',
    'html-u2-l2', 'html-u3',
  ];
  return premiumLessonPrefixes.some((p) => lessonId.startsWith(p));
}
