// src/services/notifications.ts
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

export async function requestNotificationPermission(): Promise<boolean> {
  const { status: existing } = await Notifications.getPermissionsAsync();
  if (existing === 'granted') return true;

  const { status } = await Notifications.requestPermissionsAsync();
  return status === 'granted';
}

export async function scheduleDailyReminder(timeStr: string) {
  // Cancel existing
  await Notifications.cancelAllScheduledNotificationsAsync();

  const [hour, minute] = timeStr.split(':').map(Number);

  const MESSAGES = [
    { title: '🔥 Garde ton streak vivant !', body: 'Tu n\'as pas encore codé aujourd\'hui. 5 minutes suffisent !' },
    { title: '💻 C\'est l\'heure de coder !', body: 'Tes compétences t\'attendent. Fais une leçon maintenant.' },
    { title: '⚡ 1 leçon = 10 XP', body: 'Reviens pour continuer ta progression CodeQuest !' },
    { title: '🏆 Objectif du jour', body: 'Tu es à quelques leçons de ton objectif quotidien !' },
    { title: '🐍 Python t\'appelle…', body: 'Continue là où tu t\'es arrêté. C\'était bien parti !' },
  ];

  const msg = MESSAGES[Math.floor(Math.random() * MESSAGES.length)];

  await Notifications.scheduleNotificationAsync({
    content: {
      title: msg.title,
      body: msg.body,
      sound: 'ding.wav',
      badge: 1,
      data: { screen: 'home' },
    },
    trigger: {
      hour,
      minute,
      repeats: true,
    },
  });
}

export async function scheduleStreakAtRiskNotification(streakCount: number) {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: `🔥 Ton streak de ${streakCount} jours est en danger !`,
      body: 'Fais au moins une leçon avant minuit pour le garder.',
      sound: 'ding.wav',
      data: { screen: 'home' },
    },
    trigger: {
      hour: 21,
      minute: 0,
      repeats: false,
    },
  });
}

export async function sendStreakMilestoneNotification(days: number) {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: `🎉 ${days} jours de streak !`,
      body: `Incroyable ! Tu codes depuis ${days} jours consécutifs. Continue comme ça !`,
      data: { screen: 'profile' },
    },
    trigger: null, // Immediate
  });
}

export async function setBadgeCount(count: number) {
  await Notifications.setBadgeCountAsync(count);
}
