// src/data/courses.ts

export type ExerciseType = 'fill' | 'mcq' | 'arrange' | 'debug' | 'output';

export interface Exercise {
  id: string;
  type: ExerciseType;
  prompt: string;
  code?: string;
  answer: string | number | string[];
  options?: string[];
  hint?: string;
  explanation?: string;
  xp: number;
  isPremium?: boolean;
}

export interface Lesson {
  id: string;
  title: string;
  subtitle: string;
  icon: string;
  exercises: Exercise[];
  isPremium?: boolean;
}

export interface Unit {
  id: string;
  title: string;
  icon: string;
  color: string;
  lessons: Lesson[];
}

export interface Course {
  id: string;
  label: string;
  icon: string;
  color: string;
  accent: string;
  tagline: string;
  description: string;
  units: Unit[];
}

export const COURSES: Record<string, Course> = {
  python: {
    id: 'python',
    label: 'Python',
    icon: '🐍',
    color: '#3B82F6',
    accent: '#60A5FA',
    tagline: 'Backend · IA · Automatisation',
    description: 'Le langage le plus demandé. De zéro à développeur backend.',
    units: [
      {
        id: 'py-u1',
        title: 'Premiers pas',
        icon: '🌱',
        color: '#22C55E',
        lessons: [
          {
            id: 'py-u1-l1',
            title: 'print() et affichage',
            subtitle: 'Ton premier programme',
            icon: '👋',
            exercises: [
              {
                id: 'e1', type: 'fill',
                prompt: 'Affiche le texte "Bonjour monde" dans la console',
                code: '___("Bonjour monde")',
                answer: 'print',
                hint: 'La fonction d\'affichage de Python',
                explanation: 'print() est la fonction de base pour afficher du texte en Python.',
                xp: 10,
              },
              {
                id: 'e2', type: 'mcq',
                prompt: 'Que fait ce code ?\n\nprint("Hello, Python!")',
                options: [
                  'Affiche Hello, Python! dans la console',
                  'Crée une variable nommée Hello',
                  'Génère une erreur',
                  'Ne fait rien',
                ],
                answer: 0,
                explanation: 'print() affiche le contenu entre guillemets dans le terminal.',
                xp: 10,
              },
              {
                id: 'e3', type: 'arrange',
                prompt: 'Remets les éléments dans le bon ordre pour afficher "Python rocks"',
                answer: ['print', '(', '"Python rocks"', ')'],
                xp: 15,
              },
              {
                id: 'e4', type: 'fill',
                prompt: 'Affiche le résultat de 2 + 2',
                code: 'print(2 ___ 2)',
                answer: '+',
                hint: 'L\'opérateur d\'addition',
                xp: 10,
              },
              {
                id: 'e5', type: 'output',
                prompt: 'Quel est l\'affichage de ce code ?\n\nprint("1 + 1 =", 1 + 1)',
                options: ['1 + 1 = 2', '"1 + 1 = 2"', '1 + 1 = 1 + 1', 'Erreur'],
                answer: 0,
                explanation: 'print() peut prendre plusieurs arguments séparés par des virgules.',
                xp: 15,
              },
            ],
          },
          {
            id: 'py-u1-l2',
            title: 'Variables',
            subtitle: 'Stocker des données',
            icon: '📦',
            exercises: [
              {
                id: 'e1', type: 'fill',
                prompt: 'Crée une variable "age" avec la valeur 25',
                code: '___ = 25',
                answer: 'age',
                hint: 'Le nom de la variable va à gauche du =',
                xp: 10,
              },
              {
                id: 'e2', type: 'mcq',
                prompt: 'Lequel est un nom de variable VALIDE en Python ?',
                options: ['2player', 'mon_score', 'class', 'mon-nom'],
                answer: 1,
                explanation: 'Un nom de variable ne peut pas commencer par un chiffre, utiliser des tirets, ou être un mot réservé.',
                xp: 10,
              },
              {
                id: 'e3', type: 'fill',
                prompt: 'Affiche le contenu de la variable "nom"',
                code: 'nom = "Alice"\n___(nom)',
                answer: 'print',
                xp: 10,
              },
              {
                id: 'e4', type: 'debug',
                prompt: 'Ce code contient une erreur, trouve-la !',
                code: 'prenom = "Bob"\nPrint(prenom)',
                options: [
                  'prenom devrait être PRENOM',
                  'Print doit être print (minuscule)',
                  'Les guillemets sont incorrects',
                  'Il faut un ; à la fin',
                ],
                answer: 1,
                explanation: 'Python est sensible à la casse. print() doit être en minuscules.',
                xp: 15,
              },
              {
                id: 'e5', type: 'arrange',
                prompt: 'Construis une ligne qui crée la variable score avec la valeur 100',
                answer: ['score', '=', '100'],
                xp: 15,
              },
            ],
          },
          {
            id: 'py-u1-l3',
            title: 'Types de données',
            subtitle: 'int, float, str, bool',
            icon: '🔢',
            isPremium: false,
            exercises: [
              {
                id: 'e1', type: 'mcq',
                prompt: 'Quel est le type de 42 ?',
                options: ['str', 'int', 'float', 'bool'],
                answer: 1,
                explanation: 'Les entiers sans décimale sont de type int (integer = entier).',
                xp: 10,
              },
              {
                id: 'e2', type: 'mcq',
                prompt: 'Quel est le type de 3.14 ?',
                options: ['int', 'str', 'float', 'num'],
                answer: 2,
                xp: 10,
              },
              {
                id: 'e3', type: 'fill',
                prompt: 'Convertis le nombre 42 en chaîne de texte',
                code: 'nombre = 42\ntexte = ___(nombre)',
                answer: 'str',
                hint: 'La fonction de conversion vers string',
                xp: 10,
              },
              {
                id: 'e4', type: 'output',
                prompt: 'Quel est le résultat ?\n\nprint(type(True))',
                options: ["<class 'bool'>", "<class 'int'>", "<class 'str'>", 'True'],
                answer: 0,
                xp: 15,
              },
            ],
          },
        ],
      },
      {
        id: 'py-u2',
        title: 'Logique & Contrôle',
        icon: '🔀',
        color: '#F59E0B',
        lessons: [
          {
            id: 'py-u2-l1',
            title: 'Conditions if/else',
            subtitle: 'Prendre des décisions',
            icon: '❓',
            exercises: [
              {
                id: 'e1', type: 'fill',
                prompt: 'Complète la condition pour vérifier si age >= 18',
                code: '___ age >= 18:\n    print("Majeur")',
                answer: 'if',
                hint: 'Le mot-clé pour commencer une condition',
                xp: 10,
              },
              {
                id: 'e2', type: 'mcq',
                prompt: 'Quel opérateur vérifie l\'égalité en Python ?',
                options: ['=', '==', '===', ':='],
                answer: 1,
                explanation: '= sert à assigner une valeur, == sert à comparer.',
                xp: 10,
              },
              {
                id: 'e3', type: 'arrange',
                prompt: 'Construis un if/else complet',
                answer: ['if', 'x > 0:', '    print("positif")', 'else:', '    print("négatif")'],
                xp: 20,
              },
              {
                id: 'e4', type: 'fill',
                prompt: 'Ajoute une condition "sinon si" pour 10 < score < 20',
                code: 'if score >= 20:\n    print("Bien")\n___ score >= 10:\n    print("Passable")\nelse:\n    print("Insuffisant")',
                answer: 'elif',
                hint: 'Contraction de else + if',
                xp: 15,
              },
              {
                id: 'e5', type: 'debug',
                prompt: 'Trouve l\'erreur !',
                code: 'temp = 30\nif temp > 25\n    print("Il fait chaud")',
                options: [
                  'Il manque les guillemets autour de chaud',
                  'Il manque le : après la condition',
                  'temp doit être float',
                  'print est mal orthographié',
                ],
                answer: 1,
                explanation: 'En Python, toute instruction if, for, while, def doit se terminer par ":".',
                xp: 15,
              },
            ],
          },
          {
            id: 'py-u2-l2',
            title: 'Boucle for',
            subtitle: 'Répéter des actions',
            icon: '🔄',
            isPremium: true,
            exercises: [
              {
                id: 'e1', type: 'fill',
                prompt: 'Affiche les nombres de 0 à 4',
                code: '___ i in range(5):\n    print(i)',
                answer: 'for',
                hint: 'Le mot-clé de boucle',
                xp: 10,
              },
              {
                id: 'e2', type: 'mcq',
                prompt: 'Que produit range(2, 5) ?',
                options: ['[2,3,4,5]', '[2,3,4]', '[1,2,3,4,5]', '[0,1,2,3,4]'],
                answer: 1,
                xp: 10,
              },
              {
                id: 'e3', type: 'arrange',
                prompt: 'Crée une boucle qui affiche chaque fruit d\'une liste',
                answer: ['for', 'fruit', 'in', 'fruits:', '    print(fruit)'],
                xp: 20,
              },
            ],
          },
          {
            id: 'py-u2-l3',
            title: 'Boucle while',
            subtitle: 'Boucler sous condition',
            icon: '⏳',
            isPremium: true,
            exercises: [
              {
                id: 'e1', type: 'fill',
                prompt: 'Boucle tant que compteur < 5',
                code: '___ compteur < 5:\n    print(compteur)\n    compteur += 1',
                answer: 'while',
                hint: 'Le mot-clé de boucle conditionnelle',
                xp: 10,
              },
              {
                id: 'e2', type: 'debug',
                prompt: 'Ce code génère une boucle infinie ! Pourquoi ?',
                code: 'i = 0\nwhile i < 3:\n    print(i)',
                options: [
                  'i ne s\'incrémente jamais',
                  'La condition est mauvaise',
                  'print génère une erreur',
                  'while est mal orthographié',
                ],
                answer: 0,
                explanation: 'Il faut ajouter i += 1 dans la boucle pour éviter une boucle infinie.',
                xp: 20,
              },
            ],
          },
        ],
      },
      {
        id: 'py-u3',
        title: 'Fonctions & Listes',
        icon: '⚙️',
        color: '#8B5CF6',
        lessons: [
          {
            id: 'py-u3-l1',
            title: 'Fonctions',
            subtitle: 'Réutiliser du code',
            icon: '🔧',
            isPremium: true,
            exercises: [
              {
                id: 'e1', type: 'fill',
                prompt: 'Définis une fonction nommée "saluer"',
                code: '___ saluer(prenom):\n    print("Bonjour", prenom)',
                answer: 'def',
                hint: 'Le mot-clé pour définir une fonction',
                xp: 10,
              },
              {
                id: 'e2', type: 'mcq',
                prompt: 'Comment retourner la valeur 42 depuis une fonction ?',
                options: ['send 42', 'return 42', 'output 42', 'give 42'],
                answer: 1,
                xp: 10,
              },
              {
                id: 'e3', type: 'arrange',
                prompt: 'Crée une fonction qui calcule le carré d\'un nombre',
                answer: ['def', 'carre(n):', '    return', 'n * n'],
                xp: 20,
              },
            ],
          },
          {
            id: 'py-u3-l2',
            title: 'Listes',
            subtitle: 'Collections de données',
            icon: '📋',
            isPremium: true,
            exercises: [
              {
                id: 'e1', type: 'fill',
                prompt: 'Accède au premier élément de la liste "fruits"',
                code: 'fruits = ["pomme", "banane", "kiwi"]\nprint(fruits[___])',
                answer: '0',
                hint: 'En Python, les indices commencent à 0',
                xp: 10,
              },
              {
                id: 'e2', type: 'mcq',
                prompt: 'Quelle méthode ajoute un élément à la fin d\'une liste ?',
                options: ['.add()', '.push()', '.append()', '.insert()'],
                answer: 2,
                xp: 10,
              },
            ],
          },
        ],
      },
    ],
  },

  html: {
    id: 'html',
    label: 'HTML',
    icon: '🌐',
    color: '#F97316',
    accent: '#FB923C',
    tagline: 'Frontend · Structure · Web',
    description: 'La fondation de tout site web. Construis tes premières pages.',
    units: [
      {
        id: 'html-u1',
        title: 'Structure',
        icon: '🏗️',
        color: '#F97316',
        lessons: [
          {
            id: 'html-u1-l1',
            title: 'Balises de base',
            subtitle: 'Les briques du web',
            icon: '🧱',
            exercises: [
              {
                id: 'e1', type: 'fill',
                prompt: 'Ouvre une balise de titre de niveau 1',
                code: '<___>Mon Site Web</h1>',
                answer: 'h1',
                hint: 'Heading 1 = titre principal',
                xp: 10,
              },
              {
                id: 'e2', type: 'mcq',
                prompt: 'Quelle balise crée un paragraphe ?',
                options: ['<para>', '<p>', '<txt>', '<div>'],
                answer: 1,
                explanation: '<p> est l\'élément de base pour du texte en paragraphe.',
                xp: 10,
              },
              {
                id: 'e3', type: 'arrange',
                prompt: 'Construis la structure minimale d\'une page HTML',
                answer: ['<!DOCTYPE html>', '<html>', '<body>', '</body>', '</html>'],
                xp: 20,
              },
              {
                id: 'e4', type: 'fill',
                prompt: 'Crée un titre de niveau 2',
                code: '<___>Sous-titre</___>',
                answer: 'h2',
                hint: 'Heading niveau 2',
                xp: 10,
              },
              {
                id: 'e5', type: 'debug',
                prompt: 'Trouve l\'erreur dans ce HTML',
                code: '<p>Bonjour le monde<p>',
                options: [
                  'Les guillemets manquent',
                  'La balise fermante doit être </p>',
                  'p n\'est pas une balise valide',
                  'Il manque un attribut class',
                ],
                answer: 1,
                explanation: 'Les balises HTML s\'ouvrent avec <tag> et se ferment avec </tag>.',
                xp: 15,
              },
            ],
          },
          {
            id: 'html-u1-l2',
            title: 'Titres & Texte',
            subtitle: 'h1 à h6, strong, em',
            icon: '✍️',
            exercises: [
              {
                id: 'e1', type: 'mcq',
                prompt: 'Quelle balise met le texte en GRAS ?',
                options: ['<bold>', '<b>', '<strong>', '<em>'],
                answer: 2,
                explanation: '<strong> est sémantiquement correct pour le texte important.',
                xp: 10,
              },
              {
                id: 'e2', type: 'fill',
                prompt: 'Mets le mot "important" en italique',
                code: 'Ce mot est <___>important</___>.',
                answer: 'em',
                hint: 'em = emphasis (emphase)',
                xp: 10,
              },
              {
                id: 'e3', type: 'output',
                prompt: 'Que voit-on dans le navigateur avec ce code ?\n\n<h1>Titre</h1>\n<p>Texte</p>',
                options: [
                  'Un gros titre "Titre" puis un paragraphe "Texte"',
                  'Le code HTML tel quel',
                  'Une erreur',
                  'Titre et Texte sur la même ligne',
                ],
                answer: 0,
                xp: 10,
              },
            ],
          },
          {
            id: 'html-u1-l3',
            title: 'Liens & Images',
            subtitle: '<a> et <img>',
            icon: '🔗',
            isPremium: false,
            exercises: [
              {
                id: 'e1', type: 'fill',
                prompt: 'Crée un lien vers https://google.com',
                code: '<a ___="https://google.com">Google</a>',
                answer: 'href',
                hint: 'L\'attribut qui contient l\'URL de destination',
                xp: 10,
              },
              {
                id: 'e2', type: 'mcq',
                prompt: 'Quel attribut de <img> décrit l\'image pour l\'accessibilité ?',
                options: ['title', 'src', 'alt', 'desc'],
                answer: 2,
                explanation: 'alt est lu par les lecteurs d\'écran pour les malvoyants.',
                xp: 10,
              },
              {
                id: 'e3', type: 'fill',
                prompt: 'Fais ouvrir le lien dans un nouvel onglet',
                code: '<a href="url" ___="_blank">Lien</a>',
                answer: 'target',
                hint: 'L\'attribut qui contrôle où le lien s\'ouvre',
                xp: 15,
              },
              {
                id: 'e4', type: 'arrange',
                prompt: 'Construis une balise image correcte',
                answer: ['<img', 'src="photo.jpg"', 'alt="Description"', '/>'],
                xp: 20,
              },
            ],
          },
        ],
      },
      {
        id: 'html-u2',
        title: 'Listes & Tableaux',
        icon: '📋',
        color: '#FB923C',
        lessons: [
          {
            id: 'html-u2-l1',
            title: 'Listes HTML',
            subtitle: 'ul, ol, li',
            icon: '•',
            exercises: [
              {
                id: 'e1', type: 'mcq',
                prompt: 'Quelle balise crée une liste NON ordonnée (à puces) ?',
                options: ['<ol>', '<ul>', '<li>', '<list>'],
                answer: 1,
                explanation: 'ul = unordered list. ol = ordered list (numérotée).',
                xp: 10,
              },
              {
                id: 'e2', type: 'fill',
                prompt: 'Ajoute un élément dans une liste',
                code: '<ul>\n  <___>Python</___>\n  <___>HTML</___>\n</ul>',
                answer: 'li',
                hint: 'list item',
                xp: 10,
              },
              {
                id: 'e3', type: 'arrange',
                prompt: 'Crée une liste ordonnée avec 2 éléments',
                answer: ['<ol>', '<li>Premier</li>', '<li>Deuxième</li>', '</ol>'],
                xp: 20,
              },
            ],
          },
          {
            id: 'html-u2-l2',
            title: 'Tableaux',
            subtitle: 'table, tr, td, th',
            icon: '🗂️',
            isPremium: true,
            exercises: [
              {
                id: 'e1', type: 'mcq',
                prompt: 'Quelle balise crée une ligne de tableau ?',
                options: ['<row>', '<tr>', '<td>', '<line>'],
                answer: 1,
                explanation: 'tr = table row (ligne). td = table data (cellule).',
                xp: 10,
              },
              {
                id: 'e2', type: 'fill',
                prompt: 'Crée un en-tête de colonne',
                code: '<table>\n  <tr>\n    <___>Nom</___>\n    <___>Âge</___>\n  </tr>\n</table>',
                answer: 'th',
                hint: 'table header',
                xp: 15,
              },
            ],
          },
        ],
      },
      {
        id: 'html-u3',
        title: 'Formulaires',
        icon: '📝',
        color: '#EF4444',
        lessons: [
          {
            id: 'html-u3-l1',
            title: 'Inputs & Boutons',
            subtitle: 'Collecter des données',
            icon: '⌨️',
            isPremium: true,
            exercises: [
              {
                id: 'e1', type: 'fill',
                prompt: 'Crée un champ de texte',
                code: '<input ___="text" placeholder="Ton nom">',
                answer: 'type',
                hint: 'L\'attribut qui définit le type d\'input',
                xp: 10,
              },
              {
                id: 'e2', type: 'mcq',
                prompt: 'Quel type d\'input crée un champ mot de passe (texte masqué) ?',
                options: ['secret', 'hidden', 'password', 'masked'],
                answer: 2,
                xp: 10,
              },
              {
                id: 'e3', type: 'arrange',
                prompt: 'Crée un bouton de soumission',
                answer: ['<button', 'type="submit"', '>', 'Envoyer', '</button>'],
                xp: 20,
              },
            ],
          },
        ],
      },
    ],
  },
};
