// src/screens/OnboardingScreen.tsx
import React, { useState, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, TextInput,
  Dimensions, ScrollView, Animated, Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { useAppStore } from '../store/useAppStore';
import { requestNotificationPermission, scheduleDailyReminder } from '../services/notifications';
import { COLORS, FONTS, RADIUS, SPACING } from '../utils/theme';

const { width } = Dimensions.get('window');

const GOALS = [
  { id: 'casual', label: 'Décontracté', emoji: '🌱', desc: '1 leçon / jour', color: '#22C55E', lessons: 1 },
  { id: 'regular', label: 'Régulier', emoji: '📚', desc: '3 leçons / jour', color: '#3B82F6', lessons: 3 },
  { id: 'serious', label: 'Sérieux', emoji: '🔥', desc: '5 leçons / jour', color: '#F59E0B', lessons: 5 },
  { id: 'intense', label: 'Intense', emoji: '⚡', desc: '10 leçons / jour', color: '#EF4444', lessons: 10 },
] as const;

const AVATARS = ['🧑‍💻', '👩‍💻', '🦸', '🧙', '🚀', '🐉', '🦊', '🤖', '🐍', '🌟'];

const STEPS = ['welcome', 'name', 'goal', 'notifications', 'ready'];

export default function OnboardingScreen() {
  const [step, setStep] = useState(0);
  const [name, setName] = useState('');
  const [selectedGoal, setSelectedGoal] = useState<'casual' | 'regular' | 'serious' | 'intense'>('regular');
  const [selectedAvatar, setSelectedAvatar] = useState('🧑‍💻');
  const slideAnim = useRef(new Animated.Value(0)).current;

  const { setOnboarded, setUsername, setAvatar } = useAppStore();

  const goNext = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Animated.sequence([
      Animated.timing(slideAnim, { toValue: -width, duration: 250, useNativeDriver: true }),
    ]).start(() => {
      setStep(s => s + 1);
      slideAnim.setValue(width);
      Animated.timing(slideAnim, { toValue: 0, duration: 250, useNativeDriver: true }).start();
    });
  };

  const handleFinish = async () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setUsername(name.trim() || 'Codeur');
    setAvatar(selectedAvatar);
    setOnboarded(selectedGoal);

    // Request notifications
    const granted = await requestNotificationPermission();
    if (granted) await scheduleDailyReminder('20:00');

    router.replace('/(tabs)/home');
  };

  const handleNotificationStep = async (accept: boolean) => {
    if (accept) {
      await requestNotificationPermission();
      await scheduleDailyReminder('20:00');
    }
    setStep(s => s + 1);
  };

  const renderStep = () => {
    switch (STEPS[step]) {
      case 'welcome':
        return (
          <View style={styles.stepContainer}>
            <Text style={styles.bigEmoji}>💻</Text>
            <Text style={styles.title}>Bienvenue sur{'\n'}CodeQuest</Text>
            <Text style={styles.subtitle}>
              Apprenez à coder en 5 minutes par jour.{'\n'}
              Comme Duolingo, mais pour la programmation.
            </Text>
            <View style={styles.featureList}>
              {[
                { e: '🐍', t: 'Python & HTML pour débuter' },
                { e: '🔥', t: 'Streaks & gamification' },
                { e: '⚡', t: 'Exercices interactifs' },
                { e: '🏆', t: 'Progression visible chaque jour' },
              ].map((f, i) => (
                <View key={i} style={styles.featureRow}>
                  <Text style={styles.featureEmoji}>{f.e}</Text>
                  <Text style={styles.featureText}>{f.t}</Text>
                </View>
              ))}
            </View>
            <TouchableOpacity style={styles.primaryBtn} onPress={goNext} activeOpacity={0.85}>
              <LinearGradient colors={['#3B82F6', '#8B5CF6']} style={styles.btnGradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
                <Text style={styles.btnText}>Commencer l'aventure 🚀</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        );

      case 'name':
        return (
          <View style={styles.stepContainer}>
            <Text style={styles.title}>Comment t'appelles-tu ?</Text>
            <Text style={styles.subtitle}>Choisis ton avatar et ton pseudo</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.avatarScroll} contentContainerStyle={{ paddingHorizontal: SPACING.md }}>
              {AVATARS.map((a) => (
                <TouchableOpacity
                  key={a}
                  onPress={() => { setSelectedAvatar(a); Haptics.selectionAsync(); }}
                  style={[styles.avatarBtn, selectedAvatar === a && styles.avatarSelected]}
                >
                  <Text style={styles.avatarText}>{a}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            <TextInput
              style={styles.nameInput}
              placeholder="Ton pseudo..."
              placeholderTextColor={COLORS.textMuted}
              value={name}
              onChangeText={setName}
              maxLength={20}
              autoFocus
              returnKeyType="done"
            />
            <TouchableOpacity
              style={[styles.primaryBtn, !name.trim() && styles.btnDisabled]}
              onPress={goNext}
              disabled={!name.trim()}
              activeOpacity={0.85}
            >
              <LinearGradient
                colors={name.trim() ? ['#3B82F6', '#8B5CF6'] : ['#1E293B', '#1E293B']}
                style={styles.btnGradient}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              >
                <Text style={[styles.btnText, !name.trim() && { color: COLORS.textMuted }]}>
                  Continuer →
                </Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        );

      case 'goal':
        return (
          <View style={styles.stepContainer}>
            <Text style={styles.title}>Quel est ton objectif ?</Text>
            <Text style={styles.subtitle}>Tu pourras changer ça plus tard</Text>
            <View style={styles.goalsGrid}>
              {GOALS.map((g) => (
                <TouchableOpacity
                  key={g.id}
                  onPress={() => { setSelectedGoal(g.id); Haptics.selectionAsync(); }}
                  style={[styles.goalCard, selectedGoal === g.id && { borderColor: g.color, borderWidth: 2 }]}
                  activeOpacity={0.8}
                >
                  <Text style={styles.goalEmoji}>{g.emoji}</Text>
                  <Text style={styles.goalLabel}>{g.label}</Text>
                  <Text style={[styles.goalDesc, { color: g.color }]}>{g.desc}</Text>
                  {selectedGoal === g.id && (
                    <View style={[styles.goalCheck, { backgroundColor: g.color }]}>
                      <Text style={{ color: '#fff', fontSize: 10, fontWeight: '700' }}>✓</Text>
                    </View>
                  )}
                </TouchableOpacity>
              ))}
            </View>
            <TouchableOpacity style={styles.primaryBtn} onPress={goNext} activeOpacity={0.85}>
              <LinearGradient colors={['#3B82F6', '#8B5CF6']} style={styles.btnGradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
                <Text style={styles.btnText}>C'est parti !</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        );

      case 'notifications':
        return (
          <View style={styles.stepContainer}>
            <Text style={styles.bigEmoji}>🔔</Text>
            <Text style={styles.title}>Rappels quotidiens</Text>
            <Text style={styles.subtitle}>
              On te rappellera de faire tes leçons{'\n'}pour garder ton streak vivant 🔥
            </Text>
            <View style={styles.notifPreview}>
              <View style={styles.notifCard}>
                <Text style={styles.notifTitle}>🔥 Garde ton streak vivant !</Text>
                <Text style={styles.notifBody}>Tu n'as pas encore codé aujourd'hui.</Text>
              </View>
            </View>
            <TouchableOpacity
              style={styles.primaryBtn}
              onPress={() => handleNotificationStep(true)}
              activeOpacity={0.85}
            >
              <LinearGradient colors={['#22C55E', '#16A34A']} style={styles.btnGradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
                <Text style={styles.btnText}>Activer les rappels 🔔</Text>
              </LinearGradient>
            </TouchableOpacity>
            <TouchableOpacity style={styles.skipBtn} onPress={() => handleNotificationStep(false)}>
              <Text style={styles.skipText}>Non merci</Text>
            </TouchableOpacity>
          </View>
        );

      case 'ready':
        return (
          <View style={[styles.stepContainer, { alignItems: 'center' }]}>
            <Text style={{ fontSize: 80 }}>{selectedAvatar}</Text>
            <Text style={[styles.title, { textAlign: 'center' }]}>
              Prêt à coder,{'\n'}{name.trim() || 'Codeur'} !
            </Text>
            <Text style={styles.subtitle}>
              Objectif : {GOALS.find(g => g.id === selectedGoal)?.desc}
            </Text>
            <View style={styles.readyStats}>
              {[
                { label: 'Cours disponibles', value: '2' },
                { label: 'Leçons gratuites', value: '15+' },
                { label: 'Exercices', value: '60+' },
              ].map((s, i) => (
                <View key={i} style={styles.readyStat}>
                  <Text style={styles.readyStatValue}>{s.value}</Text>
                  <Text style={styles.readyStatLabel}>{s.label}</Text>
                </View>
              ))}
            </View>
            <TouchableOpacity style={styles.primaryBtn} onPress={handleFinish} activeOpacity={0.85}>
              <LinearGradient colors={['#8B5CF6', '#3B82F6']} style={styles.btnGradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
                <Text style={styles.btnText}>Commencer à coder 💻</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        );
    }
  };

  return (
    <LinearGradient colors={['#080C14', '#0D1B2A', '#080C14']} style={styles.container}>
      <SafeAreaView style={{ flex: 1 }}>
        {/* Progress dots */}
        {step > 0 && (
          <View style={styles.dotsRow}>
            {STEPS.slice(1).map((_, i) => (
              <View
                key={i}
                style={[styles.dot, i < step && styles.dotActive]}
              />
            ))}
          </View>
        )}
        <Animated.View style={{ flex: 1, transform: [{ translateX: slideAnim }] }}>
          <ScrollView
            contentContainerStyle={styles.scroll}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            {renderStep()}
          </ScrollView>
        </Animated.View>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { flexGrow: 1, padding: SPACING.lg },
  stepContainer: { flex: 1, paddingTop: SPACING.xl },
  bigEmoji: { fontSize: 72, textAlign: 'center', marginBottom: SPACING.md },
  title: {
    fontFamily: FONTS.black,
    fontSize: 30,
    color: COLORS.text,
    lineHeight: 38,
    marginBottom: SPACING.sm,
  },
  subtitle: {
    fontFamily: FONTS.regular,
    fontSize: 16,
    color: COLORS.textMuted,
    lineHeight: 24,
    marginBottom: SPACING.xl,
  },
  featureList: { marginBottom: SPACING.xl },
  featureRow: {
    flexDirection: 'row', alignItems: 'center',
    marginBottom: SPACING.md,
    backgroundColor: 'rgba(255,255,255,0.04)',
    padding: SPACING.md, borderRadius: RADIUS.md,
    borderWidth: 1, borderColor: COLORS.border,
  },
  featureEmoji: { fontSize: 24, marginRight: SPACING.md },
  featureText: { fontFamily: FONTS.semibold, fontSize: 15, color: COLORS.text },
  primaryBtn: { borderRadius: RADIUS.lg, overflow: 'hidden', marginTop: SPACING.md },
  btnGradient: { paddingVertical: 18, alignItems: 'center' },
  btnText: { fontFamily: FONTS.bold, fontSize: 17, color: '#fff' },
  btnDisabled: { opacity: 0.5 },
  skipBtn: { padding: SPACING.md, alignItems: 'center', marginTop: SPACING.sm },
  skipText: { fontFamily: FONTS.regular, fontSize: 14, color: COLORS.textMuted },
  dotsRow: { flexDirection: 'row', justifyContent: 'center', gap: 6, paddingTop: SPACING.md },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: COLORS.textFaint },
  dotActive: { backgroundColor: COLORS.python, width: 24 },
  avatarScroll: { marginBottom: SPACING.lg },
  avatarBtn: {
    width: 56, height: 56, borderRadius: RADIUS.lg,
    backgroundColor: COLORS.bgCard, alignItems: 'center', justifyContent: 'center',
    marginRight: SPACING.sm, borderWidth: 1, borderColor: COLORS.border,
  },
  avatarSelected: { borderColor: COLORS.python, borderWidth: 2, backgroundColor: 'rgba(59,130,246,0.15)' },
  avatarText: { fontSize: 28 },
  nameInput: {
    backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md,
    padding: SPACING.md, fontSize: 18, color: COLORS.text,
    fontFamily: FONTS.regular, borderWidth: 1, borderColor: COLORS.border,
    marginBottom: SPACING.md,
  },
  goalsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.sm, marginBottom: SPACING.xl },
  goalCard: {
    width: (width - SPACING.lg * 2 - SPACING.sm) / 2 - 0.5,
    backgroundColor: COLORS.bgCard, borderRadius: RADIUS.lg,
    padding: SPACING.md, borderWidth: 1, borderColor: COLORS.border,
    position: 'relative',
  },
  goalEmoji: { fontSize: 32, marginBottom: SPACING.xs },
  goalLabel: { fontFamily: FONTS.bold, fontSize: 16, color: COLORS.text },
  goalDesc: { fontFamily: FONTS.regular, fontSize: 13, marginTop: 2 },
  goalCheck: {
    position: 'absolute', top: 8, right: 8,
    width: 20, height: 20, borderRadius: 10,
    alignItems: 'center', justifyContent: 'center',
  },
  notifPreview: { marginBottom: SPACING.xl },
  notifCard: {
    backgroundColor: COLORS.bgElevated, borderRadius: RADIUS.md,
    padding: SPACING.md, borderWidth: 1, borderColor: COLORS.border,
  },
  notifTitle: { fontFamily: FONTS.bold, fontSize: 14, color: COLORS.text, marginBottom: 4 },
  notifBody: { fontFamily: FONTS.regular, fontSize: 13, color: COLORS.textMuted },
  readyStats: {
    flexDirection: 'row', gap: SPACING.md, marginBottom: SPACING.xl,
    marginTop: SPACING.lg,
  },
  readyStat: {
    flex: 1, backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md,
    padding: SPACING.md, alignItems: 'center', borderWidth: 1, borderColor: COLORS.border,
  },
  readyStatValue: { fontFamily: FONTS.black, fontSize: 22, color: COLORS.python },
  readyStatLabel: { fontFamily: FONTS.regular, fontSize: 11, color: COLORS.textMuted, textAlign: 'center', marginTop: 4 },
});
