// src/screens/ProfileScreen.tsx
import React, { useState, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Switch, Alert, Linking,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { useAppStore } from '../store/useAppStore';
import { restorePurchases } from '../services/subscriptions';
import { COLORS, FONTS, RADIUS, SPACING } from '../utils/theme';

const ACHIEVEMENTS = [
  { id: 'first_lesson', icon: '🎯', title: 'Premier pas', desc: 'Complète ta 1ère leçon', xp: 50, condition: (s: any) => s.totalLessonsCompleted >= 1 },
  { id: 'streak_3', icon: '🔥', title: 'En feu', desc: 'Streak de 3 jours', xp: 30, condition: (s: any) => s.streak.current >= 3 },
  { id: 'streak_7', icon: '💪', title: 'Habitude', desc: 'Streak de 7 jours', xp: 100, condition: (s: any) => s.streak.current >= 7 },
  { id: 'streak_30', icon: '💎', title: 'Légendaire', desc: 'Streak de 30 jours', xp: 500, condition: (s: any) => s.streak.current >= 30 },
  { id: 'lessons_10', icon: '📚', title: 'Studieux', desc: '10 leçons complétées', xp: 100, condition: (s: any) => s.totalLessonsCompleted >= 10 },
  { id: 'lessons_50', icon: '🏆', title: 'Expert', desc: '50 leçons complétées', xp: 500, condition: (s: any) => s.totalLessonsCompleted >= 50 },
  { id: 'xp_500', icon: '⚡', title: 'Chargé', desc: '500 XP cumulés', xp: 50, condition: (s: any) => s.totalXp >= 500 },
  { id: 'level_5', icon: '🌟', title: 'Montée en puissance', desc: 'Atteins le niveau 5', xp: 200, condition: (s: any) => s.level >= 5 },
  { id: 'premium', icon: '👑', title: 'Pro Codeur', desc: 'Passe à CodeQuest Pro', xp: 100, condition: (s: any) => s.isPremium },
];

export default function ProfileScreen() {
  const store = useAppStore();
  const {
    username, avatar, totalXp, level, streak, isPremium, premiumPlan,
    notifications, soundEffects, haptics,
    toggleNotifications, toggleSound, toggleHaptics,
    totalLessonsCompleted,
  } = store;

  const [restoring, setRestoring] = useState(false);
  const [versionTaps, setVersionTaps] = useState(0);
  const versionTapTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleVersionTap = () => {
    const next = versionTaps + 1;
    setVersionTaps(next);
    if (versionTapTimer.current) clearTimeout(versionTapTimer.current);
    versionTapTimer.current = setTimeout(() => setVersionTaps(0), 3000);
    if (next >= 5) {
      setVersionTaps(0);
      router.push('/admin');
    }
  };

  const handleRestorePurchases = async () => {
    setRestoring(true);
    const restored = await restorePurchases();
    setRestoring(false);
    Alert.alert(
      restored ? '✅ Restauré' : 'Aucun achat',
      restored ? 'Ton accès Pro a été restauré.' : 'Aucun abonnement actif trouvé.'
    );
  };

  const unlockedAchievements = ACHIEVEMENTS.filter(a => a.condition(store));
  const lockedAchievements = ACHIEVEMENTS.filter(a => !a.condition(store));

  return (
    <View style={styles.container}>
      <SafeAreaView edges={['top']} style={styles.safe}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={styles.backText}>← Retour</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Mon profil</Text>
          <View style={{ width: 80 }} />
        </View>
      </SafeAreaView>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Profile hero */}
        <LinearGradient
          colors={['rgba(59,130,246,0.15)', 'transparent']}
          style={styles.profileHero}
        >
          <View style={styles.avatarLarge}>
            <Text style={styles.avatarLargeText}>{avatar}</Text>
            {isPremium && (
              <View style={styles.proTag}>
                <Text style={styles.proTagText}>⭐ Pro</Text>
              </View>
            )}
          </View>
          <Text style={styles.profileName}>{username}</Text>
          <Text style={styles.profileLevel}>Niveau {level}</Text>

          {/* Stats row */}
          <View style={styles.profileStats}>
            <View style={styles.profileStat}>
              <Text style={styles.profileStatValue}>{totalXp}</Text>
              <Text style={styles.profileStatLabel}>XP Total</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.profileStat}>
              <Text style={styles.profileStatValue}>{streak.current}</Text>
              <Text style={styles.profileStatLabel}>Streak actuel</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.profileStat}>
              <Text style={styles.profileStatValue}>{streak.longest}</Text>
              <Text style={styles.profileStatLabel}>Record streak</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.profileStat}>
              <Text style={styles.profileStatValue}>{totalLessonsCompleted}</Text>
              <Text style={styles.profileStatLabel}>Leçons</Text>
            </View>
          </View>
        </LinearGradient>

        {/* Streak calendar (last 7 days) */}
        <StreakCalendar streak={streak} />

        {/* Premium section */}
        {!isPremium ? (
          <TouchableOpacity onPress={() => router.push('/paywall')} style={styles.section} activeOpacity={0.85}>
            <LinearGradient colors={['rgba(139,92,246,0.2)', 'rgba(59,130,246,0.1)']} style={styles.premiumCard}>
              <Text style={styles.premiumCardTitle}>⭐ Passer à Pro</Text>
              <Text style={styles.premiumCardText}>Débloque toutes les leçons, exercices et certifications.</Text>
              <View style={styles.premiumCardBtn}>
                <Text style={styles.premiumCardBtnText}>Voir les plans →</Text>
              </View>
            </LinearGradient>
          </TouchableOpacity>
        ) : (
          <View style={styles.section}>
            <LinearGradient colors={['rgba(139,92,246,0.15)', 'rgba(59,130,246,0.08)']} style={styles.premiumCard}>
              <Text style={styles.premiumCardTitle}>👑 CodeQuest Pro actif</Text>
              <Text style={styles.premiumCardText}>
                Plan {premiumPlan === 'yearly' ? 'annuel' : 'mensuel'} · Merci pour ton soutien !
              </Text>
            </LinearGradient>
          </View>
        )}

        {/* Achievements */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Succès ({unlockedAchievements.length}/{ACHIEVEMENTS.length})</Text>
          <View style={styles.achievementsGrid}>
            {unlockedAchievements.map(a => (
              <View key={a.id} style={[styles.achievementCard, styles.achievementUnlocked]}>
                <Text style={styles.achievementIcon}>{a.icon}</Text>
                <Text style={styles.achievementTitle}>{a.title}</Text>
                <Text style={styles.achievementDesc}>{a.desc}</Text>
                <Text style={styles.achievementXp}>+{a.xp} XP</Text>
              </View>
            ))}
            {lockedAchievements.slice(0, 4).map(a => (
              <View key={a.id} style={[styles.achievementCard, styles.achievementLocked]}>
                <Text style={styles.achievementIconLocked}>🔒</Text>
                <Text style={styles.achievementTitle}>{a.title}</Text>
                <Text style={styles.achievementDesc}>{a.desc}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Paramètres</Text>
          <View style={styles.settingsCard}>
            <SettingRow
              label="Notifications de rappel"
              value={notifications}
              onToggle={toggleNotifications}
            />
            <View style={styles.settingSep} />
            <SettingRow
              label="Effets sonores"
              value={soundEffects}
              onToggle={toggleSound}
            />
            <View style={styles.settingSep} />
            <SettingRow
              label="Retour haptique"
              value={haptics}
              onToggle={toggleHaptics}
            />
          </View>
        </View>

        {/* Support & Legal */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Support</Text>
          <View style={styles.settingsCard}>
            {[
              { label: 'Restaurer mes achats', onPress: handleRestorePurchases },
              { label: 'Nous contacter', onPress: () => Linking.openURL('mailto:support@codequest.app') },
              { label: 'Politique de confidentialité', onPress: () => Linking.openURL('https://codequest.app/privacy') },
              { label: 'Conditions d\'utilisation', onPress: () => Linking.openURL('https://codequest.app/terms') },
              { label: 'Évaluer l\'app ⭐', onPress: () => Linking.openURL('https://codequest.app/review') },
            ].map((item, i, arr) => (
              <View key={i}>
                <TouchableOpacity style={styles.supportRow} onPress={item.onPress} activeOpacity={0.7}>
                  <Text style={styles.supportLabel}>{item.label}</Text>
                  <Text style={styles.supportArrow}>›</Text>
                </TouchableOpacity>
                {i < arr.length - 1 && <View style={styles.settingSep} />}
              </View>
            ))}
          </View>
        </View>

        <TouchableOpacity onPress={handleVersionTap} activeOpacity={1} style={styles.versionBtn}>
          <Text style={styles.versionText}>
            CodeQuest v1.0.0{versionTaps > 0 ? ` · · · · ·`.slice(0, versionTaps * 2) : ''}
          </Text>
          {versionTaps >= 3 && (
            <Text style={styles.versionHint}>
              {5 - versionTaps} tap{5 - versionTaps > 1 ? 's' : ''} pour accéder au panneau admin
            </Text>
          )}
        </TouchableOpacity>
        <View style={{ height: 100 }} />
      </ScrollView>
    </View>
  );
}

function StreakCalendar({ streak }: any) {
  const today = new Date();
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const dayStr = d.toISOString().split('T')[0];
    const isToday = i === 0;
    const lastActivity = streak.lastActivityDate;
    // Simple: assume active if within streak range
    const daysAgo = i;
    const isActive = lastActivity && daysAgo < streak.current;
    days.push({ date: d, label: ['D', 'L', 'M', 'M', 'J', 'V', 'S'][d.getDay()], isToday, isActive });
  }

  return (
    <View style={styles.calSection}>
      <Text style={styles.sectionTitle}>Streak 🔥 {streak.current} jours</Text>
      <View style={styles.calRow}>
        {days.map((day, i) => (
          <View key={i} style={styles.calDay}>
            <Text style={styles.calDayLabel}>{day.label}</Text>
            <View style={[
              styles.calDot,
              day.isActive && styles.calDotActive,
              day.isToday && styles.calDotToday,
            ]}>
              {day.isActive && <Text style={styles.calCheckmark}>✓</Text>}
            </View>
            <Text style={[styles.calDate, day.isToday && { color: COLORS.python }]}>
              {day.date.getDate()}
            </Text>
          </View>
        ))}
      </View>
      <Text style={styles.calRecord}>
        Record : {streak.longest} jours · Freezes disponibles : {streak.frozenCount} 🧊
      </Text>
    </View>
  );
}

function SettingRow({ label, value, onToggle }: any) {
  return (
    <View style={styles.settingRow}>
      <Text style={styles.settingLabel}>{label}</Text>
      <Switch
        value={value}
        onValueChange={onToggle}
        trackColor={{ false: COLORS.bgElevated, true: COLORS.python }}
        thumbColor="#fff"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  safe: { backgroundColor: COLORS.bg },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: SPACING.lg, paddingVertical: SPACING.md,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  backBtn: { width: 80 },
  backText: { fontFamily: FONTS.regular, fontSize: 14, color: COLORS.textMuted },
  headerTitle: { fontFamily: FONTS.bold, fontSize: 17, color: COLORS.text },
  profileHero: { padding: SPACING.xl, alignItems: 'center' },
  avatarLarge: { width: 80, height: 80, borderRadius: 40, backgroundColor: COLORS.bgCard, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: COLORS.python, marginBottom: SPACING.sm, position: 'relative' },
  avatarLargeText: { fontSize: 40 },
  proTag: { position: 'absolute', bottom: -8, backgroundColor: COLORS.premium, paddingHorizontal: 8, paddingVertical: 2, borderRadius: RADIUS.full },
  proTagText: { fontFamily: FONTS.bold, fontSize: 10, color: '#fff' },
  profileName: { fontFamily: FONTS.black, fontSize: 24, color: COLORS.text },
  profileLevel: { fontFamily: FONTS.regular, fontSize: 14, color: COLORS.textMuted, marginTop: 4, marginBottom: SPACING.lg },
  profileStats: { flexDirection: 'row', backgroundColor: COLORS.bgCard, borderRadius: RADIUS.lg, borderWidth: 1, borderColor: COLORS.border, overflow: 'hidden' },
  profileStat: { flex: 1, padding: SPACING.md, alignItems: 'center' },
  profileStatValue: { fontFamily: FONTS.black, fontSize: 18, color: COLORS.text },
  profileStatLabel: { fontFamily: FONTS.regular, fontSize: 10, color: COLORS.textMuted, marginTop: 2, textAlign: 'center' },
  statDivider: { width: 1, backgroundColor: COLORS.border },
  calSection: { padding: SPACING.lg },
  sectionTitle: { fontFamily: FONTS.bold, fontSize: 16, color: COLORS.text, marginBottom: SPACING.md },
  calRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: SPACING.sm },
  calDay: { alignItems: 'center', gap: 4 },
  calDayLabel: { fontFamily: FONTS.regular, fontSize: 11, color: COLORS.textMuted },
  calDot: { width: 32, height: 32, borderRadius: 16, backgroundColor: COLORS.bgCard, borderWidth: 1, borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center' },
  calDotActive: { backgroundColor: COLORS.python + '30', borderColor: COLORS.python },
  calDotToday: { borderColor: COLORS.python, borderWidth: 2 },
  calCheckmark: { fontSize: 14, color: COLORS.python },
  calDate: { fontFamily: FONTS.regular, fontSize: 11, color: COLORS.textMuted },
  calRecord: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted, textAlign: 'center' },
  section: { paddingHorizontal: SPACING.lg, marginBottom: SPACING.lg },
  premiumCard: { borderRadius: RADIUS.lg, padding: SPACING.lg, borderWidth: 1, borderColor: COLORS.premium + '30' },
  premiumCardTitle: { fontFamily: FONTS.bold, fontSize: 17, color: COLORS.text, marginBottom: 6 },
  premiumCardText: { fontFamily: FONTS.regular, fontSize: 14, color: COLORS.textMuted },
  premiumCardBtn: { marginTop: SPACING.md, backgroundColor: COLORS.premium, borderRadius: RADIUS.md, padding: SPACING.sm, alignSelf: 'flex-start', paddingHorizontal: 16 },
  premiumCardBtnText: { fontFamily: FONTS.bold, fontSize: 14, color: '#fff' },
  achievementsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.sm },
  achievementCard: { width: '47%', borderRadius: RADIUS.md, padding: SPACING.md, borderWidth: 1 },
  achievementUnlocked: { backgroundColor: COLORS.bgCard, borderColor: COLORS.python + '40' },
  achievementLocked: { backgroundColor: COLORS.bg, borderColor: COLORS.border, opacity: 0.5 },
  achievementIcon: { fontSize: 28, marginBottom: 6 },
  achievementIconLocked: { fontSize: 28, marginBottom: 6 },
  achievementTitle: { fontFamily: FONTS.bold, fontSize: 13, color: COLORS.text },
  achievementDesc: { fontFamily: FONTS.regular, fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  achievementXp: { fontFamily: FONTS.bold, fontSize: 11, color: COLORS.success, marginTop: 4 },
  settingsCard: { backgroundColor: COLORS.bgCard, borderRadius: RADIUS.lg, borderWidth: 1, borderColor: COLORS.border, overflow: 'hidden' },
  settingRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: SPACING.md },
  settingLabel: { fontFamily: FONTS.regular, fontSize: 15, color: COLORS.text },
  settingSep: { height: 1, backgroundColor: COLORS.border, marginHorizontal: SPACING.md },
  supportRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: SPACING.md },
  supportLabel: { fontFamily: FONTS.regular, fontSize: 15, color: COLORS.text },
  supportArrow: { color: COLORS.textMuted, fontSize: 20 },
  versionBtn: { alignItems: 'center', paddingVertical: SPACING.md },
  versionText: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textFaint, textAlign: 'center' },
  versionHint: { fontFamily: FONTS.regular, fontSize: 11, color: COLORS.premium, marginTop: 4, textAlign: 'center' },
});
