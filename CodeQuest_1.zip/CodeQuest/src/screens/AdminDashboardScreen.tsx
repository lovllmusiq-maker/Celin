// src/screens/AdminDashboardScreen.tsx
import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Dimensions, Animated, TextInput, Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { useAppStore } from '../store/useAppStore';
import { COURSES } from '../data/courses';
import { COLORS, FONTS, RADIUS, SPACING } from '../utils/theme';

const { width } = Dimensions.get('window');

// ─── Secret access code ────────────────────────────────────────────────────
const ADMIN_CODE = 'CQ2025';

// ─── Mock global stats (in production: fetch from Supabase/Firebase) ───────
function buildMockStats(store: ReturnType<typeof useAppStore.getState>) {
  const now = new Date();

  // Simulate realistic SaaS metrics based on local data + mock global
  const mockUsers = 1247;
  const mockPremium = 89;
  const mockMRR = mockPremium * 4.99 * 0.6 + mockPremium * 0.4 * (29.99 / 12);
  const mockARR = mockMRR * 12;

  const totalLessons = Object.values(COURSES).reduce(
    (a, c) => a + c.units.reduce((b, u) => b + u.lessons.length, 0), 0
  );
  const completedByUser = Object.keys(store.lessonProgress).filter(
    k => store.lessonProgress[k].completed
  ).length;

  // Revenue by plan
  const monthlyRevenue = 62 * 4.99;
  const yearlyRevenue = 27 * (29.99 / 12);
  const lifetimeRevenue = 0;

  // Retention simulation
  const d1 = 68, d7 = 31, d30 = 18;

  // Daily active (simulated 30 days)
  const dailyActive = Array.from({ length: 30 }, (_, i) => {
    const base = 180;
    const trend = i * 3.2;
    const noise = Math.floor(Math.random() * 40 - 20);
    return Math.max(0, Math.floor(base + trend + noise));
  });

  // Revenue last 30 days
  const revenueDaily = Array.from({ length: 30 }, (_, i) => {
    const base = 28;
    const trend = i * 0.8;
    const noise = Math.random() * 15 - 7;
    return Math.max(0, parseFloat((base + trend + noise).toFixed(2)));
  });

  // Top lessons (completion rate)
  const topLessons = [
    { name: 'print() et affichage', course: 'Python', completions: 892, rate: 94 },
    { name: 'Balises de base', course: 'HTML', completions: 741, rate: 88 },
    { name: 'Variables', course: 'Python', completions: 634, rate: 81 },
    { name: 'Titres & Texte', course: 'HTML', completions: 521, rate: 79 },
    { name: 'Types de données', course: 'Python', completions: 398, rate: 72 },
    { name: 'Liens & Images', course: 'HTML', completions: 312, rate: 68 },
    { name: 'Conditions if/else', course: 'Python', completions: 241, rate: 61 },
  ];

  // Drop-off funnel
  const funnel = [
    { step: 'Téléchargement', count: mockUsers, pct: 100 },
    { step: 'Onboarding terminé', count: 1089, pct: 87 },
    { step: 'Leçon 1 complétée', count: 892, pct: 72 },
    { step: 'Leçon 5 complétée', count: 534, pct: 43 },
    { step: 'Paywall vu', count: 312, pct: 25 },
    { step: 'Abonnement actif', count: mockPremium, pct: 7.1 },
  ];

  // Errors / crashes (mock)
  const recentErrors = [
    { msg: 'RevenueCat: product not found', count: 3, last: 'il y a 2h' },
    { msg: 'AsyncStorage: quota exceeded', count: 1, last: 'il y a 1j' },
    { msg: 'Notification permission denied', count: 47, last: 'il y a 5m' },
  ];

  return {
    users: {
      total: mockUsers,
      premium: mockPremium,
      conversionRate: ((mockPremium / mockUsers) * 100).toFixed(1),
      newToday: 23,
      newThisWeek: 142,
      activeToday: dailyActive[29],
      d1, d7, d30,
      dailyActive,
    },
    revenue: {
      mrr: mockMRR.toFixed(2),
      arr: mockARR.toFixed(2),
      total: (mockMRR * 14.3).toFixed(2),
      monthly: monthlyRevenue.toFixed(2),
      yearly: yearlyRevenue.toFixed(2),
      lifetime: lifetimeRevenue.toFixed(2),
      avgRevPerUser: (mockMRR / mockPremium).toFixed(2),
      revenueDaily,
    },
    content: {
      totalLessons,
      completedByUser,
      topLessons,
      funnel,
      avgSessionMin: 7.4,
      avgLessonsPerSession: 2.1,
    },
    localUser: {
      xp: store.totalXp,
      level: store.level,
      streak: store.streak.current,
      longestStreak: store.streak.longest,
      lessonsCompleted: store.totalLessonsCompleted,
      isPremium: store.isPremium,
      plan: store.premiumPlan,
      joinedAt: store.joinedAt,
    },
    errors: recentErrors,
  };
}

// ─── Main Component ──────────────────────────────────────────────────────────
export default function AdminDashboardScreen() {
  const [unlocked, setUnlocked] = useState(false);
  const [code, setCode] = useState('');
  const [activeTab, setActiveTab] = useState(0);
  const [attempts, setAttempts] = useState(0);
  const shakeAnim = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const store = useAppStore();
  const stats = buildMockStats(store);

  useEffect(() => {
    if (unlocked) {
      Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }).start();
    }
  }, [unlocked]);

  const tryUnlock = () => {
    if (code.toUpperCase() === ADMIN_CODE) {
      setUnlocked(true);
    } else {
      setAttempts(a => a + 1);
      setCode('');
      Animated.sequence([
        Animated.timing(shakeAnim, { toValue: 12, duration: 60, useNativeDriver: true }),
        Animated.timing(shakeAnim, { toValue: -12, duration: 60, useNativeDriver: true }),
        Animated.timing(shakeAnim, { toValue: 8, duration: 60, useNativeDriver: true }),
        Animated.timing(shakeAnim, { toValue: 0, duration: 60, useNativeDriver: true }),
      ]).start();
      if (attempts >= 4) {
        Alert.alert('🚫 Accès bloqué', 'Trop de tentatives. Réessaie plus tard.');
      }
    }
  };

  if (!unlocked) {
    return <AdminLoginScreen code={code} setCode={setCode} onSubmit={tryUnlock} shakeAnim={shakeAnim} attempts={attempts} />;
  }

  const TABS = ['📊 KPIs', '💰 Revenus', '👥 Users', '📚 Contenu', '⚠️ Logs'];

  return (
    <Animated.View style={[{ flex: 1, backgroundColor: '#050810' }, { opacity: fadeAnim }]}>
      <SafeAreaView edges={['top']} style={{ backgroundColor: '#050810' }}>
        {/* Header */}
        <LinearGradient colors={['#0A0F1C', '#050810']} style={styles.adminHeader}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={styles.backTxt}>← Retour</Text>
          </TouchableOpacity>
          <View style={styles.adminTitleRow}>
            <Text style={styles.adminTitle}>⚙️ Admin</Text>
            <View style={styles.liveBadge}>
              <View style={styles.liveDot} />
              <Text style={styles.liveText}>LIVE</Text>
            </View>
          </View>
          <Text style={styles.adminSub}>Dernière MAJ : {new Date().toLocaleTimeString('fr-FR')}</Text>
        </LinearGradient>

        {/* Tabs */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabsScroll} contentContainerStyle={styles.tabsContent}>
          {TABS.map((t, i) => (
            <TouchableOpacity key={i} onPress={() => setActiveTab(i)} style={[styles.adminTab, activeTab === i && styles.adminTabActive]}>
              <Text style={[styles.adminTabText, activeTab === i && styles.adminTabTextActive]}>{t}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </SafeAreaView>

      <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.adminContent} showsVerticalScrollIndicator={false}>
        {activeTab === 0 && <KPITab stats={stats} />}
        {activeTab === 1 && <RevenueTab stats={stats} />}
        {activeTab === 2 && <UsersTab stats={stats} />}
        {activeTab === 3 && <ContentTab stats={stats} />}
        {activeTab === 4 && <LogsTab stats={stats} />}
        <View style={{ height: 100 }} />
      </ScrollView>
    </Animated.View>
  );
}

// ─── Login Screen ────────────────────────────────────────────────────────────
function AdminLoginScreen({ code, setCode, onSubmit, shakeAnim, attempts }: any) {
  return (
    <LinearGradient colors={['#050810', '#0A0520']} style={{ flex: 1 }}>
      <SafeAreaView style={styles.loginContainer}>
        <TouchableOpacity onPress={() => router.back()} style={[styles.backBtn, { position: 'absolute', top: 16, left: SPACING.lg }]}>
          <Text style={styles.backTxt}>← Retour</Text>
        </TouchableOpacity>

        <View style={styles.loginContent}>
          <Text style={styles.loginIcon}>🔐</Text>
          <Text style={styles.loginTitle}>Accès Admin</Text>
          <Text style={styles.loginSub}>Panneau réservé aux développeurs</Text>

          <Animated.View style={[styles.codeInputWrapper, { transform: [{ translateX: shakeAnim }] }]}>
            <TextInput
              value={code}
              onChangeText={setCode}
              placeholder="Code d'accès"
              placeholderTextColor={COLORS.textFaint}
              secureTextEntry
              autoCapitalize="characters"
              style={styles.codeInput}
              onSubmitEditing={onSubmit}
              maxLength={10}
              returnKeyType="go"
            />
          </Animated.View>

          {attempts > 0 && (
            <Text style={styles.loginError}>
              ✗ Code incorrect ({attempts} tentative{attempts > 1 ? 's' : ''})
            </Text>
          )}

          <TouchableOpacity onPress={onSubmit} style={styles.loginBtn} activeOpacity={0.85}>
            <LinearGradient colors={['#8B5CF6', '#3B82F6']} style={styles.loginBtnGrad} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
              <Text style={styles.loginBtnText}>Accéder au tableau de bord</Text>
            </LinearGradient>
          </TouchableOpacity>

          <Text style={styles.loginHint}>Indice : CQ + année de lancement 😉</Text>
        </View>
      </SafeAreaView>
    </LinearGradient>
  );
}

// ─── KPI Tab ─────────────────────────────────────────────────────────────────
function KPITab({ stats }: any) {
  const kpis = [
    { label: 'Utilisateurs total', value: stats.users.total.toLocaleString(), icon: '👥', color: '#3B82F6', sub: `+${stats.users.newToday} aujourd'hui` },
    { label: 'Abonnés Pro', value: stats.users.premium.toLocaleString(), icon: '⭐', color: '#8B5CF6', sub: `${stats.users.conversionRate}% conversion` },
    { label: 'MRR', value: `${parseFloat(stats.revenue.mrr).toLocaleString('fr-FR', { minimumFractionDigits: 2 })} €`, icon: '💰', color: '#22C55E', sub: `ARR ~${parseFloat(stats.revenue.arr).toLocaleString('fr-FR', { maximumFractionDigits: 0 })} €` },
    { label: 'Actifs aujourd\'hui', value: stats.users.activeToday.toLocaleString(), icon: '🔥', color: '#F59E0B', sub: `+${stats.users.newThisWeek} cette semaine` },
  ];

  return (
    <View>
      <SectionTitle title="Vue d'ensemble" />
      <View style={styles.kpiGrid}>
        {kpis.map((k, i) => (
          <KPICard key={i} {...k} />
        ))}
      </View>

      <SectionTitle title="Rétention" />
      <View style={styles.retentionRow}>
        {[
          { label: 'J+1', value: stats.users.d1, color: '#22C55E' },
          { label: 'J+7', value: stats.users.d7, color: '#3B82F6' },
          { label: 'J+30', value: stats.users.d30, color: '#8B5CF6' },
        ].map((r, i) => (
          <View key={i} style={styles.retentionCard}>
            <Text style={[styles.retentionValue, { color: r.color }]}>{r.value}%</Text>
            <Text style={styles.retentionLabel}>{r.label}</Text>
            <View style={styles.retentionBar}>
              <View style={[styles.retentionFill, { width: `${r.value}%`, backgroundColor: r.color }]} />
            </View>
          </View>
        ))}
      </View>

      <SectionTitle title="Activité quotidienne — 30 jours" />
      <MiniBarChart data={stats.users.dailyActive} color="#3B82F6" />

      <SectionTitle title="Session utilisateur" />
      <View style={styles.sessionRow}>
        <SessionStat label="Durée moy. session" value={`${stats.content.avgSessionMin} min`} icon="⏱️" />
        <SessionStat label="Leçons / session" value={stats.content.avgLessonsPerSession} icon="📚" />
        <SessionStat label="ARPU" value={`${stats.revenue.avgRevPerUser} €`} icon="💎" />
      </View>
    </View>
  );
}

// ─── Revenue Tab ─────────────────────────────────────────────────────────────
function RevenueTab({ stats }: any) {
  return (
    <View>
      <SectionTitle title="Revenus récurrents" />
      <View style={styles.revenueHero}>
        <LinearGradient colors={['rgba(34,197,94,0.15)', 'rgba(34,197,94,0.05)']} style={styles.revenueHeroCard}>
          <Text style={styles.revenueHeroLabel}>MRR</Text>
          <Text style={styles.revenueHeroValue}>{parseFloat(stats.revenue.mrr).toLocaleString('fr-FR', { minimumFractionDigits: 2 })} €</Text>
          <Text style={styles.revenueHeroSub}>ARR projeté : {parseFloat(stats.revenue.arr).toLocaleString('fr-FR', { maximumFractionDigits: 0 })} €</Text>
        </LinearGradient>
      </View>

      <SectionTitle title="Par plan" />
      <View style={styles.planBreakdown}>
        {[
          { label: '📅 Mensuel', value: stats.revenue.monthly, users: 62, color: '#3B82F6' },
          { label: '📆 Annuel', value: stats.revenue.yearly, users: 27, color: '#8B5CF6' },
          { label: '♾️ À vie', value: stats.revenue.lifetime, users: 0, color: '#F59E0B' },
        ].map((p, i) => (
          <View key={i} style={styles.planRow}>
            <View style={[styles.planDot, { backgroundColor: p.color }]} />
            <Text style={styles.planLabel}>{p.label}</Text>
            <Text style={styles.planUsers}>{p.users} users</Text>
            <Text style={[styles.planValue, { color: p.color }]}>{parseFloat(p.value).toFixed(2)} €/m</Text>
          </View>
        ))}
      </View>

      <SectionTitle title="Revenus — 30 derniers jours" />
      <MiniBarChart data={stats.revenue.revenueDaily} color="#22C55E" prefix="€" />

      <SectionTitle title="Métriques clés" />
      <View style={styles.metricsGrid}>
        {[
          { label: 'ARPU', value: `${stats.revenue.avgRevPerUser} €`, desc: 'Revenu moyen / utilisateur Pro' },
          { label: 'LTV estimée', value: '89 €', desc: 'Valeur vie client (14 mois moy.)' },
          { label: 'CAC cible', value: '< 5 €', desc: 'Coût d\'acquisition idéal' },
          { label: 'Churn mensuel', value: '6.2%', desc: 'Taux d\'attrition abonnés' },
        ].map((m, i) => (
          <View key={i} style={styles.metricCard}>
            <Text style={styles.metricValue}>{m.value}</Text>
            <Text style={styles.metricLabel}>{m.label}</Text>
            <Text style={styles.metricDesc}>{m.desc}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

// ─── Users Tab ────────────────────────────────────────────────────────────────
function UsersTab({ stats }: any) {
  return (
    <View>
      <SectionTitle title="Ton profil (cet appareil)" />
      <View style={styles.localUserCard}>
        <View style={styles.localUserRow}>
          <Text style={styles.localUserLabel}>XP total</Text>
          <Text style={styles.localUserValue}>{stats.localUser.xp}</Text>
        </View>
        <View style={styles.localUserRow}>
          <Text style={styles.localUserLabel}>Niveau</Text>
          <Text style={styles.localUserValue}>{stats.localUser.level}</Text>
        </View>
        <View style={styles.localUserRow}>
          <Text style={styles.localUserLabel}>Streak actuel</Text>
          <Text style={styles.localUserValue}>{stats.localUser.streak} jours 🔥</Text>
        </View>
        <View style={styles.localUserRow}>
          <Text style={styles.localUserLabel}>Record streak</Text>
          <Text style={styles.localUserValue}>{stats.localUser.longestStreak} jours</Text>
        </View>
        <View style={styles.localUserRow}>
          <Text style={styles.localUserLabel}>Leçons complétées</Text>
          <Text style={styles.localUserValue}>{stats.localUser.lessonsCompleted}</Text>
        </View>
        <View style={[styles.localUserRow, { borderBottomWidth: 0 }]}>
          <Text style={styles.localUserLabel}>Statut</Text>
          <View style={[styles.statusBadge, { backgroundColor: stats.localUser.isPremium ? '#22C55E20' : '#64748B20' }]}>
            <Text style={[styles.statusBadgeText, { color: stats.localUser.isPremium ? '#22C55E' : COLORS.textMuted }]}>
              {stats.localUser.isPremium ? `⭐ Pro (${stats.localUser.plan})` : 'Gratuit'}
            </Text>
          </View>
        </View>
      </View>

      <SectionTitle title="Funnel de conversion" />
      <FunnelChart data={stats.content.funnel} />

      <SectionTitle title="Acquisition" />
      <View style={styles.acquisitionGrid}>
        {[
          { label: 'Nouveaux aujourd\'hui', value: stats.users.newToday, color: '#22C55E' },
          { label: 'Cette semaine', value: stats.users.newThisWeek, color: '#3B82F6' },
          { label: 'Actifs aujourd\'hui', value: stats.users.activeToday, color: '#F59E0B' },
          { label: 'Total inscrits', value: stats.users.total, color: '#8B5CF6' },
        ].map((a, i) => (
          <View key={i} style={styles.acquisitionCard}>
            <Text style={[styles.acquisitionValue, { color: a.color }]}>{a.value.toLocaleString()}</Text>
            <Text style={styles.acquisitionLabel}>{a.label}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

// ─── Content Tab ─────────────────────────────────────────────────────────────
function ContentTab({ stats }: any) {
  return (
    <View>
      <SectionTitle title="Top leçons (completions)" />
      {stats.content.topLessons.map((l: any, i: number) => (
        <View key={i} style={styles.topLessonRow}>
          <View style={styles.topLessonRank}>
            <Text style={styles.topLessonRankText}>#{i + 1}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.topLessonName}>{l.name}</Text>
            <Text style={styles.topLessonCourse}>{l.course}</Text>
          </View>
          <View style={{ alignItems: 'flex-end' }}>
            <Text style={styles.topLessonCount}>{l.completions.toLocaleString()}</Text>
            <View style={styles.topLessonBar}>
              <View style={[styles.topLessonFill, { width: `${l.rate}%`, backgroundColor: l.course === 'Python' ? COLORS.python : COLORS.html }]} />
            </View>
            <Text style={styles.topLessonRate}>{l.rate}%</Text>
          </View>
        </View>
      ))}

      <SectionTitle title="Catalogue" />
      {Object.values(COURSES).map((course: any) => {
        const lessonCount = course.units.reduce((a: number, u: any) => a + u.lessons.length, 0);
        const exoCount = course.units.reduce((a: number, u: any) =>
          a + u.lessons.reduce((b: number, l: any) => b + l.exercises.length, 0), 0
        );
        return (
          <View key={course.id} style={styles.courseStatRow}>
            <Text style={styles.courseStatIcon}>{course.icon}</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.courseStatName}>{course.label}</Text>
              <Text style={styles.courseStatSub}>{course.units.length} unités · {lessonCount} leçons · {exoCount} exercices</Text>
            </View>
            <View style={[styles.courseStatBadge, { backgroundColor: course.color + '25' }]}>
              <Text style={[styles.courseStatBadgeTxt, { color: course.color }]}>Actif</Text>
            </View>
          </View>
        );
      })}
    </View>
  );
}

// ─── Logs Tab ─────────────────────────────────────────────────────────────────
function LogsTab({ stats }: any) {
  return (
    <View>
      <SectionTitle title="Erreurs récentes" />
      {stats.errors.map((e: any, i: number) => (
        <View key={i} style={styles.errorRow}>
          <View style={styles.errorDot} />
          <View style={{ flex: 1 }}>
            <Text style={styles.errorMsg}>{e.msg}</Text>
            <Text style={styles.errorMeta}>{e.last} · {e.count} occurrence{e.count > 1 ? 's' : ''}</Text>
          </View>
          <View style={[styles.errorBadge, e.count > 10 && styles.errorBadgeHigh]}>
            <Text style={[styles.errorBadgeText, e.count > 10 && { color: COLORS.danger }]}>{e.count}</Text>
          </View>
        </View>
      ))}

      <SectionTitle title="Alertes business" />
      <View style={styles.alertCard}>
        <Text style={styles.alertIcon}>💡</Text>
        <View style={{ flex: 1 }}>
          <Text style={styles.alertTitle}>Taux de conversion faible</Text>
          <Text style={styles.alertText}>7.1% → objectif 10%. Teste un nouvel écran paywall.</Text>
        </View>
      </View>
      <View style={[styles.alertCard, styles.alertSuccess]}>
        <Text style={styles.alertIcon}>📈</Text>
        <View style={{ flex: 1 }}>
          <Text style={styles.alertTitle}>Rétention J+7 en hausse</Text>
          <Text style={styles.alertText}>+4 points vs. semaine dernière. Continue !</Text>
        </View>
      </View>
      <View style={styles.alertCard}>
        <Text style={styles.alertIcon}>⚠️</Text>
        <View style={{ flex: 1 }}>
          <Text style={styles.alertTitle}>Churn mensuel à surveiller</Text>
          <Text style={styles.alertText}>6.2% — envoie un email de réactivation aux inactifs 7j.</Text>
        </View>
      </View>

      <SectionTitle title="Actions rapides" />
      {[
        { label: '📧 Exporter utilisateurs CSV', color: '#3B82F6' },
        { label: '🔔 Envoyer notif push globale', color: '#F59E0B' },
        { label: '🎁 Générer code promo', color: '#22C55E' },
        { label: '🔄 Forcer sync RevenueCat', color: '#8B5CF6' },
      ].map((a, i) => (
        <TouchableOpacity
          key={i}
          onPress={() => Alert.alert('📡 Backend requis', 'Cette action nécessite une connexion à votre backend (Supabase, Firebase…).')}
          style={[styles.actionBtn, { borderColor: a.color + '40' }]}
          activeOpacity={0.75}
        >
          <Text style={[styles.actionBtnText, { color: a.color }]}>{a.label}</Text>
          <Text style={{ color: COLORS.textMuted, fontSize: 16 }}>›</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

// ─── Reusable sub-components ──────────────────────────────────────────────────

function SectionTitle({ title }: { title: string }) {
  return <Text style={styles.sectionTitle}>{title}</Text>;
}

function KPICard({ label, value, icon, color, sub }: any) {
  return (
    <View style={[styles.kpiCard, { borderColor: color + '30' }]}>
      <LinearGradient colors={[color + '18', color + '08']} style={styles.kpiGrad}>
        <Text style={styles.kpiIcon}>{icon}</Text>
        <Text style={[styles.kpiValue, { color }]}>{value}</Text>
        <Text style={styles.kpiLabel}>{label}</Text>
        <Text style={styles.kpiSub}>{sub}</Text>
      </LinearGradient>
    </View>
  );
}

function SessionStat({ label, value, icon }: any) {
  return (
    <View style={styles.sessionStat}>
      <Text style={styles.sessionStatIcon}>{icon}</Text>
      <Text style={styles.sessionStatValue}>{value}</Text>
      <Text style={styles.sessionStatLabel}>{label}</Text>
    </View>
  );
}

function MiniBarChart({ data, color, prefix = '' }: { data: number[]; color: string; prefix?: string }) {
  const max = Math.max(...data);
  const last7 = data.slice(-7);

  return (
    <View style={styles.chartContainer}>
      <View style={styles.chartBars}>
        {data.map((v, i) => {
          const h = max > 0 ? (v / max) * 64 : 0;
          const isRecent = i >= data.length - 7;
          return (
            <View key={i} style={styles.chartBarWrapper}>
              <View style={[styles.chartBar, { height: h, backgroundColor: isRecent ? color : color + '50' }]} />
            </View>
          );
        })}
      </View>
      <View style={styles.chartFooter}>
        <Text style={styles.chartLabel}>J-30</Text>
        <Text style={[styles.chartLabel, { color }]}>
          Moy 7j : {prefix}{(last7.reduce((a, b) => a + b, 0) / 7).toFixed(prefix ? 2 : 0)}
        </Text>
        <Text style={styles.chartLabel}>Aujourd'hui</Text>
      </View>
    </View>
  );
}

function FunnelChart({ data }: { data: any[] }) {
  return (
    <View style={styles.funnelContainer}>
      {data.map((step, i) => (
        <View key={i} style={styles.funnelStep}>
          <View style={[styles.funnelBar, { width: `${step.pct}%` }]}>
            <LinearGradient
              colors={['#3B82F6', '#8B5CF6']}
              style={{ flex: 1, borderRadius: 4 }}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            />
          </View>
          <View style={styles.funnelInfo}>
            <Text style={styles.funnelStep_}>{step.step}</Text>
            <Text style={styles.funnelCount}>{step.count.toLocaleString()} · {step.pct}%</Text>
          </View>
          {i < data.length - 1 && (
            <Text style={styles.funnelDrop}>
              ↓ -{(data[i].pct - data[i + 1].pct).toFixed(1)}%
            </Text>
          )}
        </View>
      ))}
    </View>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  adminHeader: { padding: SPACING.lg, paddingBottom: SPACING.sm },
  adminTitleRow: { flexDirection: 'row', alignItems: 'center', gap: SPACING.sm },
  adminTitle: { fontFamily: FONTS.black, fontSize: 22, color: COLORS.text },
  adminSub: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted, marginTop: 2 },
  liveBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: '#22C55E20', paddingHorizontal: 8, paddingVertical: 3,
    borderRadius: RADIUS.full, borderWidth: 1, borderColor: '#22C55E40',
  },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#22C55E' },
  liveText: { fontFamily: FONTS.bold, fontSize: 10, color: '#22C55E' },
  tabsScroll: { borderBottomWidth: 1, borderBottomColor: COLORS.border },
  tabsContent: { paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm, gap: SPACING.xs },
  adminTab: {
    paddingHorizontal: 14, paddingVertical: 7,
    borderRadius: RADIUS.full, borderWidth: 1, borderColor: COLORS.border,
    backgroundColor: COLORS.bgCard,
  },
  adminTabActive: { backgroundColor: '#8B5CF6', borderColor: '#8B5CF6' },
  adminTabText: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted },
  adminTabTextActive: { fontFamily: FONTS.bold, color: '#fff' },
  adminContent: { padding: SPACING.lg },
  backBtn: { marginBottom: SPACING.sm },
  backTxt: { fontFamily: FONTS.regular, fontSize: 13, color: COLORS.textMuted },
  sectionTitle: { fontFamily: FONTS.bold, fontSize: 14, color: COLORS.textMuted, letterSpacing: 0.5, textTransform: 'uppercase', marginTop: SPACING.lg, marginBottom: SPACING.sm },
  kpiGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.sm },
  kpiCard: { width: (width - SPACING.lg * 2 - SPACING.sm) / 2, borderRadius: RADIUS.lg, borderWidth: 1, overflow: 'hidden' },
  kpiGrad: { padding: SPACING.md },
  kpiIcon: { fontSize: 24, marginBottom: 6 },
  kpiValue: { fontFamily: FONTS.black, fontSize: 22 },
  kpiLabel: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted, marginTop: 2 },
  kpiSub: { fontFamily: FONTS.regular, fontSize: 11, color: COLORS.textFaint, marginTop: 4 },
  retentionRow: { flexDirection: 'row', gap: SPACING.sm },
  retentionCard: { flex: 1, backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md, padding: SPACING.md, borderWidth: 1, borderColor: COLORS.border },
  retentionValue: { fontFamily: FONTS.black, fontSize: 22 },
  retentionLabel: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted, marginBottom: SPACING.sm },
  retentionBar: { height: 4, backgroundColor: COLORS.bgElevated, borderRadius: 2, overflow: 'hidden' },
  retentionFill: { height: '100%', borderRadius: 2 },
  chartContainer: { backgroundColor: COLORS.bgCard, borderRadius: RADIUS.lg, padding: SPACING.md, borderWidth: 1, borderColor: COLORS.border },
  chartBars: { flexDirection: 'row', alignItems: 'flex-end', height: 72, gap: 2 },
  chartBarWrapper: { flex: 1, justifyContent: 'flex-end' },
  chartBar: { borderRadius: 2, minHeight: 2 },
  chartFooter: { flexDirection: 'row', justifyContent: 'space-between', marginTop: SPACING.sm },
  chartLabel: { fontFamily: FONTS.regular, fontSize: 10, color: COLORS.textMuted },
  sessionRow: { flexDirection: 'row', gap: SPACING.sm },
  sessionStat: { flex: 1, backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md, padding: SPACING.md, alignItems: 'center', borderWidth: 1, borderColor: COLORS.border },
  sessionStatIcon: { fontSize: 20, marginBottom: 4 },
  sessionStatValue: { fontFamily: FONTS.black, fontSize: 18, color: COLORS.text },
  sessionStatLabel: { fontFamily: FONTS.regular, fontSize: 10, color: COLORS.textMuted, textAlign: 'center', marginTop: 3 },
  revenueHero: { marginBottom: SPACING.sm },
  revenueHeroCard: { borderRadius: RADIUS.lg, padding: SPACING.xl, alignItems: 'center', borderWidth: 1, borderColor: '#22C55E30' },
  revenueHeroLabel: { fontFamily: FONTS.bold, fontSize: 14, color: COLORS.textMuted, letterSpacing: 2, textTransform: 'uppercase' },
  revenueHeroValue: { fontFamily: FONTS.black, fontSize: 42, color: '#22C55E', marginTop: SPACING.xs },
  revenueHeroSub: { fontFamily: FONTS.regular, fontSize: 14, color: COLORS.textMuted, marginTop: 4 },
  planBreakdown: { backgroundColor: COLORS.bgCard, borderRadius: RADIUS.lg, borderWidth: 1, borderColor: COLORS.border, overflow: 'hidden' },
  planRow: { flexDirection: 'row', alignItems: 'center', padding: SPACING.md, borderBottomWidth: 1, borderBottomColor: COLORS.border, gap: SPACING.sm },
  planDot: { width: 10, height: 10, borderRadius: 5 },
  planLabel: { flex: 1, fontFamily: FONTS.regular, fontSize: 14, color: COLORS.text },
  planUsers: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted },
  planValue: { fontFamily: FONTS.bold, fontSize: 14, minWidth: 70, textAlign: 'right' },
  metricsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.sm },
  metricCard: { width: (width - SPACING.lg * 2 - SPACING.sm) / 2, backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md, padding: SPACING.md, borderWidth: 1, borderColor: COLORS.border },
  metricValue: { fontFamily: FONTS.black, fontSize: 20, color: COLORS.text },
  metricLabel: { fontFamily: FONTS.bold, fontSize: 12, color: COLORS.textMuted, marginTop: 2 },
  metricDesc: { fontFamily: FONTS.regular, fontSize: 11, color: COLORS.textFaint, marginTop: 4, lineHeight: 16 },
  localUserCard: { backgroundColor: COLORS.bgCard, borderRadius: RADIUS.lg, borderWidth: 1, borderColor: COLORS.border, overflow: 'hidden' },
  localUserRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: SPACING.md, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  localUserLabel: { fontFamily: FONTS.regular, fontSize: 14, color: COLORS.textMuted },
  localUserValue: { fontFamily: FONTS.bold, fontSize: 14, color: COLORS.text },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: RADIUS.full },
  statusBadgeText: { fontFamily: FONTS.bold, fontSize: 12 },
  funnelContainer: { gap: 6 },
  funnelStep: { marginBottom: 4 },
  funnelInfo: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 4 },
  funnelStep_: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.text },
  funnelCount: { fontFamily: FONTS.bold, fontSize: 12, color: COLORS.textMuted },
  funnelBar: { height: 8, backgroundColor: COLORS.bgElevated, borderRadius: 4, overflow: 'hidden', maxWidth: '100%' },
  funnelDrop: { fontFamily: FONTS.regular, fontSize: 10, color: COLORS.danger, textAlign: 'right', marginTop: 2 },
  acquisitionGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.sm },
  acquisitionCard: { width: (width - SPACING.lg * 2 - SPACING.sm) / 2, backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md, padding: SPACING.md, borderWidth: 1, borderColor: COLORS.border },
  acquisitionValue: { fontFamily: FONTS.black, fontSize: 28 },
  acquisitionLabel: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted, marginTop: 4 },
  topLessonRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md, padding: SPACING.md, marginBottom: 8, borderWidth: 1, borderColor: COLORS.border, gap: SPACING.sm },
  topLessonRank: { width: 28, height: 28, borderRadius: 8, backgroundColor: COLORS.bgElevated, alignItems: 'center', justifyContent: 'center' },
  topLessonRankText: { fontFamily: FONTS.bold, fontSize: 11, color: COLORS.textMuted },
  topLessonName: { fontFamily: FONTS.bold, fontSize: 13, color: COLORS.text },
  topLessonCourse: { fontFamily: FONTS.regular, fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  topLessonCount: { fontFamily: FONTS.bold, fontSize: 13, color: COLORS.text, textAlign: 'right' },
  topLessonBar: { width: 60, height: 4, backgroundColor: COLORS.bgElevated, borderRadius: 2, overflow: 'hidden', marginTop: 4 },
  topLessonFill: { height: '100%', borderRadius: 2 },
  topLessonRate: { fontFamily: FONTS.regular, fontSize: 10, color: COLORS.textMuted, textAlign: 'right', marginTop: 2 },
  courseStatRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md, padding: SPACING.md, marginBottom: 8, borderWidth: 1, borderColor: COLORS.border, gap: SPACING.sm },
  courseStatIcon: { fontSize: 28 },
  courseStatName: { fontFamily: FONTS.bold, fontSize: 14, color: COLORS.text },
  courseStatSub: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted, marginTop: 2 },
  courseStatBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: RADIUS.full },
  courseStatBadgeTxt: { fontFamily: FONTS.bold, fontSize: 11 },
  errorRow: { flexDirection: 'row', alignItems: 'flex-start', backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md, padding: SPACING.md, marginBottom: 8, borderWidth: 1, borderColor: COLORS.border, gap: SPACING.sm },
  errorDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: COLORS.danger, marginTop: 4 },
  errorMsg: { fontFamily: FONTS.bold, fontSize: 13, color: COLORS.text },
  errorMeta: { fontFamily: FONTS.regular, fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  errorBadge: { backgroundColor: 'rgba(239,68,68,0.1)', paddingHorizontal: 8, paddingVertical: 3, borderRadius: RADIUS.full },
  errorBadgeHigh: { backgroundColor: 'rgba(239,68,68,0.2)' },
  errorBadgeText: { fontFamily: FONTS.bold, fontSize: 12, color: COLORS.textMuted },
  alertCard: { flexDirection: 'row', gap: SPACING.sm, backgroundColor: 'rgba(245,158,11,0.1)', borderRadius: RADIUS.md, padding: SPACING.md, marginBottom: 8, borderWidth: 1, borderColor: 'rgba(245,158,11,0.25)' },
  alertSuccess: { backgroundColor: 'rgba(34,197,94,0.08)', borderColor: 'rgba(34,197,94,0.2)' },
  alertIcon: { fontSize: 22 },
  alertTitle: { fontFamily: FONTS.bold, fontSize: 13, color: COLORS.text },
  alertText: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted, marginTop: 2, lineHeight: 18 },
  actionBtn: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md, padding: SPACING.md, marginBottom: 8, borderWidth: 1 },
  actionBtnText: { fontFamily: FONTS.bold, fontSize: 14 },
  loginContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: SPACING.xl },
  loginContent: { width: '100%', alignItems: 'center' },
  loginIcon: { fontSize: 64, marginBottom: SPACING.md },
  loginTitle: { fontFamily: FONTS.black, fontSize: 28, color: COLORS.text },
  loginSub: { fontFamily: FONTS.regular, fontSize: 14, color: COLORS.textMuted, marginTop: 6, marginBottom: SPACING.xl },
  codeInputWrapper: { width: '100%', marginBottom: SPACING.sm },
  codeInput: { backgroundColor: COLORS.bgCard, borderRadius: RADIUS.lg, padding: SPACING.md, fontSize: 18, color: COLORS.text, fontFamily: FONTS.monoBold, borderWidth: 1, borderColor: COLORS.border, textAlign: 'center', letterSpacing: 4 },
  loginError: { fontFamily: FONTS.regular, fontSize: 13, color: COLORS.danger, marginBottom: SPACING.md },
  loginBtn: { width: '100%', borderRadius: RADIUS.lg, overflow: 'hidden', marginBottom: SPACING.md },
  loginBtnGrad: { padding: 16, alignItems: 'center' },
  loginBtnText: { fontFamily: FONTS.bold, fontSize: 16, color: '#fff' },
  loginHint: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textFaint, marginTop: SPACING.sm },
});
