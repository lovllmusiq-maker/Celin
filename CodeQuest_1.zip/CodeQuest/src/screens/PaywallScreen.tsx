// src/screens/PaywallScreen.tsx
import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
  ActivityIndicator, Animated, Alert, Platform, Linking,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { fetchOfferings, purchasePackage, restorePurchases, PLAN_DISPLAY } from '../services/subscriptions';
import { useAppStore } from '../store/useAppStore';
import { COLORS, FONTS, RADIUS, SPACING } from '../utils/theme';

const FEATURES_FREE = [
  { text: '2 premières unités de chaque cours', ok: true },
  { text: '~15 leçons gratuites', ok: true },
  { text: 'Streak & XP', ok: true },
  { text: 'Leçons avancées', ok: false },
  { text: 'Projets pratiques', ok: false },
  { text: 'Certificats', ok: false },
];

const FEATURES_PRO = [
  { text: 'Toutes les leçons débloquées', ok: true },
  { text: 'Exercices avancés illimités', ok: true },
  { text: 'Projets pratiques guidés', ok: true },
  { text: 'Certificat de complétion', ok: true },
  { text: 'Streak Freeze offerts', ok: true },
  { text: 'Sans publicité', ok: true },
];

export default function PaywallScreen() {
  const [selectedPlan, setSelectedPlan] = useState(1); // yearly by default
  const [packages, setPackages] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [fetchingPlans, setFetchingPlans] = useState(true);
  const { isPremium } = useAppStore();
  const glowAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (isPremium) { router.back(); return; }
    loadOfferings();
    startGlowAnimation();
  }, []);

  const startGlowAnimation = () => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(glowAnim, { toValue: 1, duration: 1500, useNativeDriver: false }),
        Animated.timing(glowAnim, { toValue: 0, duration: 1500, useNativeDriver: false }),
      ])
    ).start();
  };

  const loadOfferings = async () => {
    setFetchingPlans(true);
    try {
      const pkgs = await fetchOfferings();
      setPackages(pkgs);
    } catch (e) {
      console.log('Could not fetch offerings, using display data');
    } finally {
      setFetchingPlans(false);
    }
  };

  const handlePurchase = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setLoading(true);
    try {
      const plan = PLAN_DISPLAY[selectedPlan];
      const pkg = packages.find(p => p.product.identifier === plan.id);

      if (!pkg) {
        // Dev mode: simulate purchase
        Alert.alert(
          '🛒 Mode dev',
          `Achat simulé : ${plan.title} ${plan.price}`,
          [{ text: 'OK', onPress: () => router.back() }]
        );
        return;
      }

      const result = await purchasePackage(pkg);
      if (result.success) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        Alert.alert('🎉 Bienvenue dans CodeQuest Pro !', 'Toutes les leçons sont maintenant débloquées.', [
          { text: 'Commencer', onPress: () => router.back() },
        ]);
      } else if (result.error !== 'cancelled') {
        Alert.alert('Erreur', result.error || 'Une erreur est survenue. Réessaie.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRestore = async () => {
    setLoading(true);
    const restored = await restorePurchases();
    setLoading(false);
    if (restored) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert('✅ Achats restaurés', 'Ton accès Premium a été restauré.', [
        { text: 'Super !', onPress: () => router.back() },
      ]);
    } else {
      Alert.alert('Aucun achat trouvé', 'Aucun abonnement actif n\'a été trouvé pour ce compte.');
    }
  };

  const glowOpacity = glowAnim.interpolate({ inputRange: [0, 1], outputRange: [0.3, 0.7] });

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#0D0820', '#080C14']}
        style={StyleSheet.absoluteFill}
      />

      {/* Glow background */}
      <Animated.View style={[styles.glowBg, { opacity: glowOpacity }]} />

      <SafeAreaView style={{ flex: 1 }}>
        {/* Close button */}
        <TouchableOpacity onPress={() => router.back()} style={styles.closeBtn}>
          <Text style={styles.closeText}>✕</Text>
        </TouchableOpacity>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
          {/* Hero */}
          <View style={styles.hero}>
            <Text style={styles.heroEmoji}>⭐</Text>
            <Text style={styles.heroTitle}>CodeQuest Pro</Text>
            <Text style={styles.heroSub}>Débloque tout ton potentiel de développeur</Text>
          </View>

          {/* Features comparison */}
          <View style={styles.featuresRow}>
            <View style={styles.featuresCol}>
              <Text style={styles.featuresTitle}>Gratuit</Text>
              {FEATURES_FREE.map((f, i) => (
                <View key={i} style={styles.featureItem}>
                  <Text style={[styles.featureIcon, { color: f.ok ? COLORS.success : COLORS.textFaint }]}>
                    {f.ok ? '✓' : '✗'}
                  </Text>
                  <Text style={[styles.featureText, !f.ok && { color: COLORS.textFaint }]}>{f.text}</Text>
                </View>
              ))}
            </View>
            <View style={[styles.featuresCol, styles.featuresProCol]}>
              <LinearGradient colors={['#8B5CF620', '#3B82F620']} style={styles.featuresProGrad}>
                <Text style={[styles.featuresTitle, { color: COLORS.premiumLight }]}>Pro ⭐</Text>
                {FEATURES_PRO.map((f, i) => (
                  <View key={i} style={styles.featureItem}>
                    <Text style={[styles.featureIcon, { color: COLORS.success }]}>✓</Text>
                    <Text style={styles.featureText}>{f.text}</Text>
                  </View>
                ))}
              </LinearGradient>
            </View>
          </View>

          {/* Plans */}
          <Text style={styles.plansTitle}>Choisis ton plan</Text>
          {fetchingPlans ? (
            <ActivityIndicator color={COLORS.premium} style={{ marginVertical: SPACING.xl }} />
          ) : (
            <View style={styles.plansContainer}>
              {PLAN_DISPLAY.map((plan, i) => (
                <TouchableOpacity
                  key={plan.id}
                  onPress={() => { setSelectedPlan(i); Haptics.selectionAsync(); }}
                  activeOpacity={0.85}
                  style={[
                    styles.planCard,
                    selectedPlan === i && { borderColor: plan.color, borderWidth: 2 },
                    plan.isPopular && styles.planPopular,
                  ]}
                >
                  {plan.isPopular && (
                    <LinearGradient
                      colors={[plan.color, plan.color + 'AA']}
                      style={styles.popularBadge}
                      start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                    >
                      <Text style={styles.popularText}>⚡ LE PLUS POPULAIRE</Text>
                    </LinearGradient>
                  )}
                  {plan.savings && !plan.isPopular && (
                    <View style={[styles.savingsBadge, { backgroundColor: plan.color + '25', borderColor: plan.color + '50' }]}>
                      <Text style={[styles.savingsText, { color: plan.color }]}>{plan.savings}</Text>
                    </View>
                  )}
                  <View style={styles.planRow}>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.planTitle}>{plan.title}</Text>
                      <Text style={styles.planMonthly}>{plan.monthlyPrice}</Text>
                    </View>
                    <View style={styles.planPriceBox}>
                      <Text style={[styles.planPrice, { color: plan.color }]}>{plan.price}</Text>
                      <Text style={styles.planPeriod}>{plan.period}</Text>
                    </View>
                    <View style={[styles.radioOuter, selectedPlan === i && { borderColor: plan.color }]}>
                      {selectedPlan === i && <View style={[styles.radioInner, { backgroundColor: plan.color }]} />}
                    </View>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          )}

          {/* CTA */}
          <TouchableOpacity
            onPress={handlePurchase}
            disabled={loading}
            activeOpacity={0.85}
            style={styles.ctaBtn}
          >
            <LinearGradient
              colors={['#8B5CF6', '#3B82F6']}
              style={styles.ctaGrad}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.ctaText}>
                  Commencer avec {PLAN_DISPLAY[selectedPlan].title} →
                </Text>
              )}
            </LinearGradient>
          </TouchableOpacity>

          {/* Legal */}
          <Text style={styles.legalText}>
            {PLAN_DISPLAY[selectedPlan].id.includes('lifetime')
              ? 'Paiement unique, aucun renouvellement.'
              : `L'abonnement se renouvelle automatiquement. Annulable à tout moment dans les réglages ${Platform.OS === 'ios' ? 'App Store' : 'Google Play'}.`}
          </Text>

          {/* Restore */}
          <TouchableOpacity onPress={handleRestore} style={styles.restoreBtn}>
            <Text style={styles.restoreText}>Restaurer mes achats</Text>
          </TouchableOpacity>

          {/* Legal links */}
          <View style={styles.legalLinks}>
            <TouchableOpacity onPress={() => Linking.openURL('https://codequest.app/privacy')}>
              <Text style={styles.legalLink}>Confidentialité</Text>
            </TouchableOpacity>
            <Text style={styles.legalSep}>·</Text>
            <TouchableOpacity onPress={() => Linking.openURL('https://codequest.app/terms')}>
              <Text style={styles.legalLink}>CGU</Text>
            </TouchableOpacity>
          </View>

          <View style={{ height: 40 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0D0820' },
  glowBg: {
    position: 'absolute', top: -100, left: '20%',
    width: 300, height: 300, borderRadius: 150,
    backgroundColor: '#8B5CF6',
    shadowColor: '#8B5CF6', shadowRadius: 80, shadowOpacity: 1,
    shadowOffset: { width: 0, height: 0 },
  },
  closeBtn: {
    position: 'absolute', top: 12, right: SPACING.lg,
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center', justifyContent: 'center', zIndex: 10,
  },
  closeText: { color: COLORS.text, fontSize: 16 },
  content: { padding: SPACING.lg, paddingTop: SPACING.xl },
  hero: { alignItems: 'center', marginBottom: SPACING.xl, marginTop: SPACING.md },
  heroEmoji: { fontSize: 56, marginBottom: SPACING.sm },
  heroTitle: {
    fontFamily: FONTS.black, fontSize: 32, color: COLORS.text,
    textAlign: 'center',
  },
  heroSub: {
    fontFamily: FONTS.regular, fontSize: 15, color: COLORS.textMuted,
    textAlign: 'center', marginTop: SPACING.xs,
  },
  featuresRow: { flexDirection: 'row', gap: SPACING.sm, marginBottom: SPACING.xl },
  featuresCol: { flex: 1 },
  featuresProCol: { borderRadius: RADIUS.lg, overflow: 'hidden' },
  featuresProGrad: { padding: SPACING.md, borderRadius: RADIUS.lg, borderWidth: 1, borderColor: COLORS.premium + '30' },
  featuresTitle: { fontFamily: FONTS.bold, fontSize: 14, color: COLORS.text, marginBottom: SPACING.md },
  featureItem: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 6, gap: 6 },
  featureIcon: { fontSize: 13, fontFamily: FONTS.bold, marginTop: 1 },
  featureText: { fontSize: 12, color: COLORS.textMuted, fontFamily: FONTS.regular, flex: 1 },
  plansTitle: { fontFamily: FONTS.bold, fontSize: 17, color: COLORS.text, marginBottom: SPACING.md },
  plansContainer: { gap: SPACING.sm, marginBottom: SPACING.xl },
  planCard: {
    backgroundColor: COLORS.bgCard, borderRadius: RADIUS.lg,
    borderWidth: 1, borderColor: COLORS.border, overflow: 'hidden',
  },
  planPopular: { borderColor: '#8B5CF6' },
  popularBadge: {
    paddingVertical: 6, paddingHorizontal: SPACING.md,
    alignItems: 'center',
  },
  popularText: { fontFamily: FONTS.bold, fontSize: 11, color: '#fff', letterSpacing: 1 },
  savingsBadge: {
    margin: SPACING.sm, marginBottom: 0, alignSelf: 'flex-start',
    paddingHorizontal: 10, paddingVertical: 4, borderRadius: RADIUS.full,
    borderWidth: 1,
  },
  savingsText: { fontFamily: FONTS.bold, fontSize: 11 },
  planRow: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.sm,
    padding: SPACING.md,
  },
  planTitle: { fontFamily: FONTS.bold, fontSize: 16, color: COLORS.text },
  planMonthly: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted, marginTop: 2 },
  planPriceBox: { alignItems: 'flex-end' },
  planPrice: { fontFamily: FONTS.black, fontSize: 20 },
  planPeriod: { fontFamily: FONTS.regular, fontSize: 11, color: COLORS.textMuted },
  radioOuter: {
    width: 22, height: 22, borderRadius: 11,
    borderWidth: 2, borderColor: COLORS.textMuted,
    alignItems: 'center', justifyContent: 'center',
  },
  radioInner: { width: 12, height: 12, borderRadius: 6 },
  ctaBtn: { borderRadius: RADIUS.lg, overflow: 'hidden', marginBottom: SPACING.md },
  ctaGrad: { padding: 18, alignItems: 'center' },
  ctaText: { fontFamily: FONTS.bold, fontSize: 17, color: '#fff' },
  legalText: {
    fontFamily: FONTS.regular, fontSize: 11, color: COLORS.textMuted,
    textAlign: 'center', lineHeight: 16, marginBottom: SPACING.md,
  },
  restoreBtn: { alignItems: 'center', padding: SPACING.sm },
  restoreText: { fontFamily: FONTS.regular, fontSize: 13, color: COLORS.textMuted },
  legalLinks: { flexDirection: 'row', justifyContent: 'center', gap: SPACING.sm, marginTop: SPACING.sm },
  legalLink: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted, textDecorationLine: 'underline' },
  legalSep: { color: COLORS.textFaint, fontSize: 12 },
});
