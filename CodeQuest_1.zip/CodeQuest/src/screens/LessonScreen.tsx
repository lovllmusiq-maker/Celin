// src/screens/LessonScreen.tsx
import React, { useState, useRef, useCallback } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, TextInput,
  ScrollView, Animated, Dimensions, Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { COURSES } from '../data/courses';
import { useAppStore } from '../store/useAppStore';
import { COLORS, FONTS, RADIUS, SPACING } from '../utils/theme';

const { width } = Dimensions.get('window');

export default function LessonScreen() {
  const { courseId, unitId, lessonId } = useLocalSearchParams<{
    courseId: string; unitId: string; lessonId: string;
  }>();

  const course = COURSES[courseId];
  const unit = course?.units.find(u => u.id === unitId);
  const lesson = unit?.lessons.find(l => l.id === lessonId);

  const [idx, setIdx] = useState(0);
  const [lives, setLives] = useState(3);
  const [xpEarned, setXpEarned] = useState(0);
  const [combo, setCombo] = useState(0);
  const [answered, setAnswered] = useState<null | 'correct' | 'wrong'>(null);
  const [finished, setFinished] = useState(false);
  const [wrongCount, setWrongCount] = useState(0);
  const shakeAnim = useRef(new Animated.Value(0)).current;
  const feedbackAnim = useRef(new Animated.Value(0)).current;

  const { completeLesson, soundEffects, haptics } = useAppStore();

  if (!lesson) return null;

  const ex = lesson.exercises[idx];
  const progress = ((idx) / lesson.exercises.length) * 100;

  const triggerShake = () => {
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 10, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -10, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 10, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0, duration: 60, useNativeDriver: true }),
    ]).start();
  };

  const showFeedback = () => {
    Animated.spring(feedbackAnim, { toValue: 1, useNativeDriver: true, tension: 100, friction: 8 }).start();
  };

  const handleResult = useCallback((correct: boolean, bonusXp?: number) => {
    if (correct) {
      const xp = ex.xp + (combo >= 2 ? Math.floor(ex.xp * 0.5) : 0) + (bonusXp ?? 0);
      setXpEarned(p => p + xp);
      setCombo(c => c + 1);
      setAnswered('correct');
      if (haptics) Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } else {
      setLives(l => l - 1);
      setCombo(0);
      setWrongCount(c => c + 1);
      setAnswered('wrong');
      triggerShake();
      if (haptics) Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }
    showFeedback();
  }, [ex, combo, haptics]);

  const handleNext = () => {
    if (lives <= 0) {
      Alert.alert(
        '💔 Plus de vies !',
        'Tu as épuisé tes vies. Recommence la leçon pour t\'améliorer.',
        [
          { text: 'Recommencer', onPress: () => { setIdx(0); setLives(3); setAnswered(null); setXpEarned(0); setWrongCount(0); } },
          { text: 'Quitter', onPress: () => router.back() },
        ]
      );
      return;
    }

    feedbackAnim.setValue(0);

    if (idx + 1 < lesson.exercises.length) {
      setIdx(i => i + 1);
      setAnswered(null);
    } else {
      // Calculate stars: 3 = perfect, 2 = < 2 wrong, 1 = completed
      const stars = wrongCount === 0 ? 3 : wrongCount <= 2 ? 2 : 1;
      completeLesson(lesson.id, xpEarned, stars);
      setFinished(true);
    }
  };

  if (finished) {
    return <LessonComplete lesson={lesson} xp={xpEarned} wrongCount={wrongCount} onContinue={() => router.back()} />;
  }

  const feedbackSlide = feedbackAnim.interpolate({ inputRange: [0, 1], outputRange: [100, 0] });

  return (
    <View style={styles.container}>
      <SafeAreaView edges={['top']} style={styles.safe}>
        {/* Top bar */}
        <View style={styles.topBar}>
          <TouchableOpacity onPress={() => {
            Alert.alert('Quitter ?', 'Ta progression sera perdue.', [
              { text: 'Annuler', style: 'cancel' },
              { text: 'Quitter', style: 'destructive', onPress: () => router.back() },
            ]);
          }} style={styles.closeTopBtn}>
            <Text style={styles.closeTopText}>✕</Text>
          </TouchableOpacity>

          <View style={styles.progressBar}>
            <LinearGradient
              colors={[course.color, course.accent]}
              style={[styles.progressFill, { width: `${progress}%` }]}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            />
          </View>

          <View style={styles.livesRow}>
            {[...Array(3)].map((_, i) => (
              <Text key={i} style={[styles.heart, i >= lives && styles.heartEmpty]}>❤️</Text>
            ))}
          </View>
        </View>
      </SafeAreaView>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Combo badge */}
        {combo >= 2 && (
          <View style={styles.comboBadge}>
            <LinearGradient colors={['#F59E0B', '#EF4444']} style={styles.comboGrad} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
              <Text style={styles.comboText}>🔥 COMBO x{combo} !</Text>
            </LinearGradient>
          </View>
        )}

        <Text style={styles.exerciseNum}>{idx + 1} / {lesson.exercises.length}</Text>

        <Animated.View style={{ transform: [{ translateX: shakeAnim }] }}>
          {ex.type === 'fill' && (
            <FillExercise exercise={ex} answered={answered} onResult={handleResult} course={course} />
          )}
          {ex.type === 'mcq' && (
            <MCQExercise exercise={ex} answered={answered} onResult={handleResult} course={course} />
          )}
          {ex.type === 'output' && (
            <MCQExercise exercise={ex} answered={answered} onResult={handleResult} course={course} isOutput />
          )}
          {ex.type === 'arrange' && (
            <ArrangeExercise exercise={ex} answered={answered} onResult={handleResult} course={course} />
          )}
          {ex.type === 'debug' && (
            <MCQExercise exercise={ex} answered={answered} onResult={handleResult} course={course} isDebug />
          )}
        </Animated.View>
      </ScrollView>

      {/* Feedback panel */}
      {answered && (
        <Animated.View style={[styles.feedbackPanel, { transform: [{ translateY: feedbackSlide }] }]}>
          <View style={[styles.feedbackInner, answered === 'correct' ? styles.feedbackCorrect : styles.feedbackWrong]}>
            <View style={styles.feedbackRow}>
              <View>
                <Text style={[styles.feedbackTitle, { color: answered === 'correct' ? COLORS.success : COLORS.danger }]}>
                  {answered === 'correct' ? '✓ Parfait !' : '✗ Pas tout à fait…'}
                </Text>
                {answered === 'wrong' && ex.hint && (
                  <Text style={styles.feedbackHint}>💡 {ex.hint}</Text>
                )}
                {answered === 'correct' && combo >= 2 && (
                  <Text style={styles.feedbackBonus}>+{ex.xp + Math.floor(ex.xp * 0.5)} XP (combo !)</Text>
                )}
                {answered === 'correct' && combo < 2 && (
                  <Text style={styles.feedbackBonus}>+{ex.xp} XP</Text>
                )}
                {answered === 'wrong' && ex.explanation && (
                  <Text style={styles.feedbackExplanation}>{ex.explanation}</Text>
                )}
              </View>
              <TouchableOpacity onPress={handleNext} style={styles.nextBtn}>
                <LinearGradient
                  colors={answered === 'correct' ? [COLORS.success, COLORS.successDark] : [COLORS.danger, COLORS.dangerDark]}
                  style={styles.nextGrad}
                  start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                >
                  <Text style={styles.nextText}>Suivant →</Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        </Animated.View>
      )}
    </View>
  );
}

// ── Exercise Components ───────────────────────────────────────────────────────

function FillExercise({ exercise, answered, onResult, course }: any) {
  const [value, setValue] = useState('');
  const parts = exercise.code.split('___');

  const check = () => {
    if (!value.trim()) return;
    onResult(value.trim().toLowerCase() === exercise.answer.toLowerCase());
  };

  return (
    <View>
      <Text style={styles.prompt}>{exercise.prompt}</Text>
      <View style={styles.codeBlock}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View style={styles.codeRow}>
            {parts.map((part: string, i: number) => (
              <View key={i} style={styles.codeRowInner}>
                <Text style={styles.codeText}>{part}</Text>
                {i < parts.length - 1 && (
                  <TextInput
                    value={value}
                    onChangeText={setValue}
                    onSubmitEditing={check}
                    editable={!answered}
                    placeholder="???"
                    placeholderTextColor={COLORS.textFaint}
                    style={[
                      styles.fillInput,
                      { borderBottomColor: answered === 'correct' ? COLORS.success : answered === 'wrong' ? COLORS.danger : course.color },
                      answered === 'correct' && { color: COLORS.success },
                      answered === 'wrong' && { color: COLORS.danger },
                    ]}
                    autoFocus
                    autoCapitalize="none"
                    autoCorrect={false}
                    returnKeyType="done"
                  />
                )}
              </View>
            ))}
          </View>
        </ScrollView>
      </View>
      {!answered && (
        <TouchableOpacity
          onPress={check}
          disabled={!value.trim()}
          style={[styles.verifyBtn, !value.trim() && styles.verifyBtnDisabled]}
        >
          <Text style={[styles.verifyText, !value.trim() && { color: COLORS.textMuted }]}>
            Vérifier
          </Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

function MCQExercise({ exercise, answered, onResult, course, isOutput, isDebug }: any) {
  const [selected, setSelected] = useState<number | null>(null);

  const getOptionStyle = (i: number) => {
    if (!answered) {
      return selected === i
        ? { bg: course.color + '20', border: course.color + '60' }
        : { bg: COLORS.bgCard, border: COLORS.border };
    }
    if (i === exercise.answer) return { bg: 'rgba(34,197,94,0.15)', border: COLORS.success + '60' };
    if (i === selected) return { bg: 'rgba(239,68,68,0.15)', border: COLORS.danger + '60' };
    return { bg: COLORS.bgCard, border: COLORS.border };
  };

  return (
    <View>
      {isDebug && (
        <View style={styles.debugBanner}>
          <Text style={styles.debugText}>🐛 Trouve le bug</Text>
        </View>
      )}
      {isOutput && (
        <View style={styles.outputBanner}>
          <Text style={styles.outputText}>💻 Quel est l'affichage ?</Text>
        </View>
      )}
      <Text style={styles.prompt}>{exercise.prompt}</Text>
      {exercise.code && (
        <View style={styles.codeBlock}>
          <Text style={styles.codeText}>{exercise.code}</Text>
        </View>
      )}
      <View style={styles.optionsContainer}>
        {exercise.options.map((opt: string, i: number) => {
          const s = getOptionStyle(i);
          const isCorrect = answered && i === exercise.answer;
          const isWrong = answered && selected === i && i !== exercise.answer;
          return (
            <TouchableOpacity
              key={i}
              onPress={() => { if (!answered) { setSelected(i); onResult(i === exercise.answer); } }}
              activeOpacity={0.8}
              style={[styles.option, { backgroundColor: s.bg, borderColor: s.border }]}
            >
              <View style={[styles.optionLetter, isCorrect && styles.optionLetterCorrect, isWrong && styles.optionLetterWrong]}>
                <Text style={styles.optionLetterText}>
                  {isCorrect ? '✓' : isWrong ? '✗' : String.fromCharCode(65 + i)}
                </Text>
              </View>
              <Text style={[styles.optionText, isCorrect && { color: COLORS.success }, isWrong && { color: COLORS.danger }]}>
                {opt}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

function ArrangeExercise({ exercise, answered, onResult, course }: any) {
  const [bank, setBank] = useState(() => [...exercise.answer].sort(() => Math.random() - 0.5));
  const [arranged, setArranged] = useState<string[]>([]);

  const addWord = (word: string, i: number) => {
    if (answered) return;
    Haptics.selectionAsync();
    setArranged(a => [...a, word]);
    setBank(b => b.filter((_, idx) => idx !== i));
  };

  const removeWord = (word: string, i: number) => {
    if (answered) return;
    Haptics.selectionAsync();
    setBank(b => [...b, word]);
    setArranged(a => a.filter((_, idx) => idx !== i));
  };

  const check = () => {
    const correct = arranged.join('|') === exercise.answer.join('|');
    onResult(correct);
  };

  const isCorrect = answered === 'correct';
  const isWrong = answered === 'wrong';

  return (
    <View>
      <Text style={styles.prompt}>{exercise.prompt}</Text>

      {/* Drop zone */}
      <View style={[
        styles.dropZone,
        isCorrect && { borderColor: COLORS.success },
        isWrong && { borderColor: COLORS.danger },
      ]}>
        {arranged.length === 0 && (
          <Text style={styles.dropZonePlaceholder}>Touche les mots ci-dessous…</Text>
        )}
        <View style={styles.wordRow}>
          {arranged.map((w, i) => (
            <TouchableOpacity key={i} onPress={() => removeWord(w, i)} activeOpacity={0.7}>
              <View style={[styles.wordChip, styles.wordChipActive, { borderColor: course.color + '60', backgroundColor: course.color + '20' }]}>
                <Text style={[styles.wordChipText, { color: COLORS.text }]}>{w}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Word bank */}
      <View style={styles.wordBank}>
        {bank.map((w, i) => (
          <TouchableOpacity key={i} onPress={() => addWord(w, i)} activeOpacity={0.7}>
            <View style={styles.wordChip}>
              <Text style={styles.wordChipText}>{w}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>

      {!answered && (
        <TouchableOpacity
          onPress={check}
          disabled={arranged.length !== exercise.answer.length}
          style={[styles.verifyBtn, arranged.length !== exercise.answer.length && styles.verifyBtnDisabled]}
        >
          <Text style={[styles.verifyText, arranged.length !== exercise.answer.length && { color: COLORS.textMuted }]}>
            Vérifier
          </Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

// ── Lesson Complete ───────────────────────────────────────────────────────────
function LessonComplete({ lesson, xp, wrongCount, onContinue }: any) {
  const stars = wrongCount === 0 ? 3 : wrongCount <= 2 ? 2 : 1;
  const scaleAnim = useRef(new Animated.Value(0)).current;

  React.useEffect(() => {
    Animated.spring(scaleAnim, { toValue: 1, tension: 80, friction: 8, useNativeDriver: true }).start();
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  }, []);

  return (
    <LinearGradient colors={['#080C14', '#0D2010']} style={styles.completeContainer}>
      <SafeAreaView style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: SPACING.xl }}>
        <Animated.View style={[styles.trophyWrapper, { transform: [{ scale: scaleAnim }] }]}>
          <Text style={styles.trophyEmoji}>🏆</Text>
        </Animated.View>

        <Text style={styles.completeTitle}>Leçon terminée !</Text>
        <Text style={styles.completeSubtitle}>{lesson.title}</Text>

        {/* Stars */}
        <View style={styles.starsRow}>
          {[1, 2, 3].map(i => (
            <Text key={i} style={[styles.star, i <= stars ? styles.starActive : styles.starInactive]}>⭐</Text>
          ))}
        </View>

        {/* Stats */}
        <View style={styles.completeStats}>
          {[
            { icon: '⚡', label: 'XP gagnés', value: `+${xp}` },
            { icon: '⭐', label: 'Étoiles', value: `${stars}/3` },
            { icon: '✗', label: 'Erreurs', value: wrongCount },
          ].map((s, i) => (
            <View key={i} style={styles.completeStat}>
              <Text style={styles.completeStatIcon}>{s.icon}</Text>
              <Text style={styles.completeStatValue}>{s.value}</Text>
              <Text style={styles.completeStatLabel}>{s.label}</Text>
            </View>
          ))}
        </View>

        <TouchableOpacity onPress={onContinue} style={styles.continueBtn} activeOpacity={0.85}>
          <LinearGradient colors={[COLORS.success, COLORS.successDark]} style={styles.continueGrad}>
            <Text style={styles.continueText}>Continuer 🚀</Text>
          </LinearGradient>
        </TouchableOpacity>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  safe: { backgroundColor: COLORS.bg },
  topBar: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm,
    gap: SPACING.sm, borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  closeTopBtn: {
    width: 34, height: 34, borderRadius: 17,
    backgroundColor: COLORS.bgCard, alignItems: 'center', justifyContent: 'center',
  },
  closeTopText: { color: COLORS.textMuted, fontSize: 14 },
  progressBar: {
    flex: 1, height: 8, backgroundColor: COLORS.bgElevated,
    borderRadius: 4, overflow: 'hidden',
  },
  progressFill: { height: '100%', borderRadius: 4 },
  livesRow: { flexDirection: 'row', gap: 2 },
  heart: { fontSize: 18 },
  heartEmpty: { opacity: 0.2 },
  scroll: { flex: 1 },
  scrollContent: { padding: SPACING.lg, paddingBottom: 160 },
  comboBadge: { alignSelf: 'flex-end', borderRadius: RADIUS.full, overflow: 'hidden', marginBottom: SPACING.md },
  comboGrad: { paddingHorizontal: 14, paddingVertical: 6 },
  comboText: { fontFamily: FONTS.bold, fontSize: 13, color: '#fff' },
  exerciseNum: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted, marginBottom: SPACING.sm },
  prompt: { fontFamily: FONTS.bold, fontSize: 20, color: COLORS.text, lineHeight: 28, marginBottom: SPACING.lg },
  codeBlock: {
    backgroundColor: '#0A0F1A', borderRadius: RADIUS.md,
    padding: SPACING.md, marginBottom: SPACING.lg,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.06)',
  },
  codeRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap' },
  codeRowInner: { flexDirection: 'row', alignItems: 'center' },
  codeText: { fontFamily: FONTS.mono, fontSize: 15, color: '#94A3B8', lineHeight: 26 },
  fillInput: {
    fontFamily: FONTS.monoBold, fontSize: 15, color: COLORS.text,
    borderBottomWidth: 2, paddingHorizontal: 6, paddingBottom: 2,
    minWidth: 60, textAlign: 'center',
  },
  verifyBtn: {
    backgroundColor: COLORS.python, borderRadius: RADIUS.lg,
    padding: 16, alignItems: 'center',
  },
  verifyBtnDisabled: { backgroundColor: COLORS.bgElevated },
  verifyText: { fontFamily: FONTS.bold, fontSize: 16, color: '#fff' },
  optionsContainer: { gap: SPACING.sm },
  option: {
    borderRadius: RADIUS.md, borderWidth: 1,
    padding: SPACING.md, flexDirection: 'row', alignItems: 'center', gap: SPACING.sm,
  },
  optionLetter: {
    width: 32, height: 32, borderRadius: 8, backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center', justifyContent: 'center',
  },
  optionLetterCorrect: { backgroundColor: COLORS.success },
  optionLetterWrong: { backgroundColor: COLORS.danger },
  optionLetterText: { fontFamily: FONTS.bold, fontSize: 13, color: '#fff' },
  optionText: { fontFamily: FONTS.regular, fontSize: 15, color: COLORS.text, flex: 1 },
  debugBanner: { backgroundColor: 'rgba(239,68,68,0.12)', borderRadius: RADIUS.sm, padding: SPACING.sm, marginBottom: SPACING.sm, borderWidth: 1, borderColor: COLORS.danger + '30' },
  debugText: { fontFamily: FONTS.bold, fontSize: 13, color: COLORS.danger },
  outputBanner: { backgroundColor: 'rgba(59,130,246,0.12)', borderRadius: RADIUS.sm, padding: SPACING.sm, marginBottom: SPACING.sm, borderWidth: 1, borderColor: COLORS.python + '30' },
  outputText: { fontFamily: FONTS.bold, fontSize: 13, color: COLORS.python },
  dropZone: {
    minHeight: 64, borderRadius: RADIUS.md, borderWidth: 2,
    borderColor: COLORS.border, borderStyle: 'dashed',
    padding: SPACING.sm, marginBottom: SPACING.md,
  },
  dropZonePlaceholder: { fontFamily: FONTS.regular, fontSize: 13, color: COLORS.textFaint, padding: SPACING.xs },
  wordRow: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.xs },
  wordBank: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.xs, marginBottom: SPACING.lg },
  wordChip: {
    paddingHorizontal: 14, paddingVertical: 9, borderRadius: 10,
    backgroundColor: COLORS.bgCard, borderWidth: 1, borderColor: COLORS.border,
  },
  wordChipActive: { borderWidth: 1 },
  wordChipText: { fontFamily: FONTS.mono, fontSize: 14, color: COLORS.textMuted },
  feedbackPanel: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
  },
  feedbackInner: {
    borderTopLeftRadius: RADIUS.xl, borderTopRightRadius: RADIUS.xl,
    borderTopWidth: 1, padding: SPACING.lg,
  },
  feedbackCorrect: {
    backgroundColor: 'rgba(34,197,94,0.15)',
    borderTopColor: COLORS.success + '40',
  },
  feedbackWrong: {
    backgroundColor: 'rgba(239,68,68,0.15)',
    borderTopColor: COLORS.danger + '40',
  },
  feedbackRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: SPACING.md },
  feedbackTitle: { fontFamily: FONTS.bold, fontSize: 17 },
  feedbackHint: { fontFamily: FONTS.regular, fontSize: 13, color: COLORS.textMuted, marginTop: 4 },
  feedbackBonus: { fontFamily: FONTS.semibold, fontSize: 13, color: COLORS.success, marginTop: 4 },
  feedbackExplanation: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted, marginTop: 4, maxWidth: 200 },
  nextBtn: { borderRadius: RADIUS.md, overflow: 'hidden', flexShrink: 0 },
  nextGrad: { paddingHorizontal: 20, paddingVertical: 14 },
  nextText: { fontFamily: FONTS.bold, fontSize: 15, color: '#fff' },
  completeContainer: { flex: 1 },
  trophyWrapper: { marginBottom: SPACING.md },
  trophyEmoji: { fontSize: 80 },
  completeTitle: { fontFamily: FONTS.black, fontSize: 32, color: COLORS.success, marginBottom: SPACING.xs },
  completeSubtitle: { fontFamily: FONTS.regular, fontSize: 16, color: COLORS.textMuted, marginBottom: SPACING.xl },
  starsRow: { flexDirection: 'row', gap: SPACING.sm, marginBottom: SPACING.xl },
  star: { fontSize: 36 },
  starActive: { opacity: 1 },
  starInactive: { opacity: 0.2, grayscale: 1 },
  completeStats: { flexDirection: 'row', gap: SPACING.md, marginBottom: SPACING.xl },
  completeStat: {
    backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md,
    padding: SPACING.md, alignItems: 'center', flex: 1,
    borderWidth: 1, borderColor: COLORS.border,
  },
  completeStatIcon: { fontSize: 24, marginBottom: 4 },
  completeStatValue: { fontFamily: FONTS.black, fontSize: 20, color: COLORS.success },
  completeStatLabel: { fontFamily: FONTS.regular, fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  continueBtn: { width: '100%', borderRadius: RADIUS.lg, overflow: 'hidden' },
  continueGrad: { padding: 18, alignItems: 'center' },
  continueText: { fontFamily: FONTS.bold, fontSize: 17, color: '#fff' },
});
