// src/screens/HomeScreen.tsx
import React, { useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { useAppStore } from '../store/useAppStore';
import { COURSES } from '../data/courses';
import { COLORS, FONTS, RADIUS, SPACING } from '../utils/theme';

const { width } = Dimensions.get('window');

function getStreakEmoji(s: number) {
  if (s >= 100) return '🌟';
  if (s >= 30) return '💎';
  if (s >= 7) return '🔥';
  if (s >= 1) return '🔥';
  return '💤';
}

export default function HomeScreen() {
  const {
    username, avatar, streak, totalXp, level, xpToNextLevel,
    dailyGoal, dailyDone, isPremium, lessonProgress, resetDailyIfNeeded,
  } = useAppStore();

  useEffect(() => {
    resetDailyIfNeeded();
  }, []);

  const courses = Object.values(COURSES);

  return (
    <View style={styles.container}>
      <SafeAreaView edges={['top']} style={styles.safe}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.push('/profile')} style={styles.profileBtn}>
            <Text style={styles.avatarText}>{avatar}</Text>
          </TouchableOpacity>
          <View style={{ flex: 1, marginLeft: SPACING.sm }}>
            <Text style={styles.greeting}>Bonjour, {username} !</Text>
            <Text style={styles.levelText}>Niveau {level} · {totalXp} XP total</Text>
          </View>
          {!isPremium && (
            <TouchableOpacity onPress={() => router.push('/paywall')} style={styles.premiumBadge}>
              <LinearGradient colors={['#8B5CF6', '#6D28D9']} style={styles.premiumGrad} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
                <Text style={styles.premiumBadgeText}>⭐ Pro</Text>
              </LinearGradient>
            </TouchableOpacity>
          )}
        </View>
      </SafeAreaView>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Stats row */}
        <View style={styles.statsRow}>
          <StatPill
            icon={getStreakEmoji(streak.current)}
            value={`${streak.current}`}
            label="Streak"
            color={COLORS.warning}
            onPress={() => router.push('/streak')}
          />
          <StatPill
            icon="⚡"
            value={`${totalXp}`}
            label="XP Total"
            color={COLORS.python}
          />
          <StatPill
            icon="🏆"
            value={`Niv ${level}`}
            label="Niveau"
            color={COLORS.premium}
            onPress={() => router.push('/leaderboard')}
          />
        </View>

        {/* XP Level Bar */}
        <View style={styles.card}>
          <View style={styles.xpHeader}>
            <Text style={styles.cardLabel}>Progression niveau {level}</Text>
            <Text style={styles.xpText}>{xpToNextLevel} XP pour niveau {level + 1}</Text>
          </View>
          <View style={styles.xpTrack}>
            <LinearGradient
              colors={[COLORS.premium, COLORS.python]}
              style={[styles.xpFill, { width: `${Math.min(100 - (xpToNextLevel / 100) * 100, 100)}%` }]}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            />
          </View>
        </View>

        {/* Daily Goal */}
        <DailyGoalCard dailyDone={dailyDone} dailyGoal={dailyGoal} />

        {/* Streak Risk Warning */}
        {streak.current > 0 && streak.lastActivityDate !== new Date().toISOString().split('T')[0] && (
          <View style={styles.warningCard}>
            <Text style={styles.warningEmoji}>⚠️</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.warningTitle}>Streak en danger !</Text>
              <Text style={styles.warningText}>Fais une leçon avant minuit pour garder ton streak de {streak.current} jours.</Text>
            </View>
          </View>
        )}

        {/* Courses */}
        <Text style={styles.sectionTitle}>Parcours</Text>
        {courses.map((course) => {
          const totalLessons = course.units.reduce((a, u) => a + u.lessons.length, 0);
          const doneLessons = course.units.reduce(
            (a, u) => a + u.lessons.filter(l => lessonProgress[l.id]?.completed).length, 0
          );
          const pct = totalLessons > 0 ? Math.round((doneLessons / totalLessons) * 100) : 0;

          return (
            <CourseCard
              key={course.id}
              course={course}
              doneLessons={doneLessons}
              totalLessons={totalLessons}
              pct={pct}
              onPress={() => router.push(`/course/${course.id}`)}
            />
          );
        })}

        {/* Coming soon */}
        <View style={styles.comingSoon}>
          <Text style={styles.comingSoonEmoji}>⚡</Text>
          <View>
            <Text style={styles.comingSoonTitle}>JavaScript</Text>
            <Text style={styles.comingSoonText}>Bientôt disponible</Text>
          </View>
          <View style={styles.comingSoonBadge}>
            <Text style={styles.comingSoonBadgeText}>Soon</Text>
          </View>
        </View>

        {/* Leaderboard teaser */}
        <TouchableOpacity
          style={styles.leaderCard}
          onPress={() => router.push('/leaderboard')}
          activeOpacity={0.8}
        >
          <LinearGradient
            colors={['rgba(251,191,36,0.12)', 'rgba(245,158,11,0.06)']}
            style={styles.leaderGrad}
          >
            <Text style={styles.leaderTitle}>🏆 Classement</Text>
            <Text style={styles.leaderText}>Rejoins les meilleurs codeurs de la semaine</Text>
            <Text style={styles.leaderArrow}>Voir →</Text>
          </LinearGradient>
        </TouchableOpacity>

        <View style={{ height: 100 }} />
      </ScrollView>
    </View>
  );
}

function StatPill({ icon, value, label, color, onPress }: any) {
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={onPress ? 0.7 : 1}
      style={[styles.statPill, { borderColor: color + '30' }]}
    >
      <Text style={styles.statIcon}>{icon}</Text>
      <Text style={[styles.statValue, { color }]}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </TouchableOpacity>
  );
}

function DailyGoalCard({ dailyDone, dailyGoal }: { dailyDone: number; dailyGoal: number }) {
  const pct = Math.min((dailyDone / dailyGoal) * 100, 100);
  const isDone = dailyDone >= dailyGoal;

  return (
    <View style={[styles.card, isDone && { borderColor: COLORS.success + '40' }]}>
      <View style={styles.goalHeader}>
        <View>
          <Text style={styles.cardLabel}>Objectif du jour</Text>
          <Text style={styles.goalSub}>{dailyDone}/{dailyGoal} leçons</Text>
        </View>
        <Text style={{ fontSize: 32 }}>{isDone ? '✅' : '🎯'}</Text>
      </View>
      <View style={styles.goalTrack}>
        <LinearGradient
          colors={isDone ? [COLORS.success, COLORS.successDark] : [COLORS.python, COLORS.premium]}
          style={[styles.goalFill, { width: `${pct}%` }]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
        />
      </View>
      {isDone && (
        <Text style={styles.goalDoneText}>🎉 Objectif atteint ! Reviens demain.</Text>
      )}
    </View>
  );
}

function CourseCard({ course, doneLessons, totalLessons, pct, onPress }: any) {
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.85}
      style={styles.courseCard}
    >
      <LinearGradient
        colors={[course.color + '20', course.color + '08']}
        style={styles.courseGrad}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
      >
        <View style={styles.courseRow}>
          <View style={[styles.courseIcon, { backgroundColor: course.color + '25' }]}>
            <Text style={styles.courseIconText}>{course.icon}</Text>
          </View>
          <View style={{ flex: 1, marginLeft: SPACING.md }}>
            <View style={styles.courseTitleRow}>
              <Text style={styles.courseName}>{course.label}</Text>
              <Text style={[styles.coursePct, { color: course.color }]}>{pct}%</Text>
            </View>
            <Text style={styles.courseTag}>{course.tagline}</Text>
            <View style={styles.courseTrack}>
              <View style={[styles.courseFill, { width: `${pct}%`, backgroundColor: course.color }]} />
            </View>
            <Text style={styles.courseSub}>{doneLessons}/{totalLessons} leçons</Text>
          </View>
        </View>
      </LinearGradient>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  safe: { backgroundColor: COLORS.bg },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: SPACING.lg, paddingVertical: SPACING.md,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
    backgroundColor: COLORS.bg,
  },
  profileBtn: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: COLORS.bgCard, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: COLORS.border,
  },
  avatarText: { fontSize: 22 },
  greeting: { fontFamily: FONTS.bold, fontSize: 16, color: COLORS.text },
  levelText: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted, marginTop: 2 },
  premiumBadge: { borderRadius: RADIUS.full, overflow: 'hidden' },
  premiumGrad: { paddingHorizontal: 14, paddingVertical: 6 },
  premiumBadgeText: { fontFamily: FONTS.bold, fontSize: 13, color: '#fff' },
  scroll: { flex: 1 },
  scrollContent: { padding: SPACING.lg },
  statsRow: { flexDirection: 'row', gap: SPACING.sm, marginBottom: SPACING.md },
  statPill: {
    flex: 1, backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md,
    padding: SPACING.md, alignItems: 'center', borderWidth: 1,
  },
  statIcon: { fontSize: 20, marginBottom: 4 },
  statValue: { fontFamily: FONTS.black, fontSize: 18 },
  statLabel: { fontFamily: FONTS.regular, fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  card: {
    backgroundColor: COLORS.bgCard, borderRadius: RADIUS.lg,
    padding: SPACING.md, marginBottom: SPACING.md,
    borderWidth: 1, borderColor: COLORS.border,
  },
  cardLabel: { fontFamily: FONTS.bold, fontSize: 14, color: COLORS.text },
  xpHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: SPACING.sm },
  xpText: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted },
  xpTrack: { height: 8, backgroundColor: COLORS.border, borderRadius: 4, overflow: 'hidden' },
  xpFill: { height: '100%', borderRadius: 4 },
  goalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: SPACING.sm },
  goalSub: { fontFamily: FONTS.regular, fontSize: 13, color: COLORS.textMuted, marginTop: 2 },
  goalTrack: { height: 10, backgroundColor: COLORS.border, borderRadius: 5, overflow: 'hidden' },
  goalFill: { height: '100%', borderRadius: 5 },
  goalDoneText: { fontFamily: FONTS.semibold, fontSize: 13, color: COLORS.success, marginTop: SPACING.sm },
  warningCard: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(239,68,68,0.12)', borderRadius: RADIUS.md,
    padding: SPACING.md, marginBottom: SPACING.md,
    borderWidth: 1, borderColor: 'rgba(239,68,68,0.3)',
    gap: SPACING.sm,
  },
  warningEmoji: { fontSize: 24 },
  warningTitle: { fontFamily: FONTS.bold, fontSize: 14, color: COLORS.danger },
  warningText: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted, marginTop: 2 },
  sectionTitle: { fontFamily: FONTS.black, fontSize: 18, color: COLORS.text, marginBottom: SPACING.md },
  courseCard: { borderRadius: RADIUS.lg, overflow: 'hidden', marginBottom: SPACING.md, borderWidth: 1, borderColor: COLORS.border },
  courseGrad: { padding: SPACING.md },
  courseRow: { flexDirection: 'row', alignItems: 'center' },
  courseIcon: { width: 56, height: 56, borderRadius: RADIUS.md, alignItems: 'center', justifyContent: 'center' },
  courseIconText: { fontSize: 28 },
  courseTitleRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  courseName: { fontFamily: FONTS.black, fontSize: 18, color: COLORS.text },
  coursePct: { fontFamily: FONTS.bold, fontSize: 14 },
  courseTag: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted, marginTop: 2, marginBottom: SPACING.sm },
  courseTrack: { height: 6, backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 3, overflow: 'hidden' },
  courseFill: { height: '100%', borderRadius: 3 },
  courseSub: { fontFamily: FONTS.regular, fontSize: 11, color: COLORS.textMuted, marginTop: 4 },
  comingSoon: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.02)',
    borderRadius: RADIUS.lg, padding: SPACING.md,
    borderWidth: 1, borderColor: COLORS.border,
    borderStyle: 'dashed', marginBottom: SPACING.md,
    opacity: 0.5, gap: SPACING.md,
  },
  comingSoonEmoji: { fontSize: 28 },
  comingSoonTitle: { fontFamily: FONTS.bold, fontSize: 16, color: COLORS.text },
  comingSoonText: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textMuted },
  comingSoonBadge: { marginLeft: 'auto', backgroundColor: COLORS.bgElevated, paddingHorizontal: 10, paddingVertical: 4, borderRadius: RADIUS.full },
  comingSoonBadgeText: { fontFamily: FONTS.bold, fontSize: 11, color: COLORS.textMuted },
  leaderCard: { borderRadius: RADIUS.lg, overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(251,191,36,0.2)' },
  leaderGrad: { padding: SPACING.md },
  leaderTitle: { fontFamily: FONTS.bold, fontSize: 15, color: COLORS.gold },
  leaderText: { fontFamily: FONTS.regular, fontSize: 13, color: COLORS.textMuted, marginTop: 4 },
  leaderArrow: { fontFamily: FONTS.bold, fontSize: 13, color: COLORS.gold, marginTop: SPACING.sm },
});
